package me.donate;

import cn.nukkit.Player;
import cn.nukkit.block.Block;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerInteractEvent;
import cn.nukkit.event.player.PlayerItemConsumeEvent;
import cn.nukkit.item.Item;
import cn.nukkit.item.enchantment.Enchantment;
import cn.nukkit.math.Vector3;
import cn.nukkit.nbt.tag.CompoundTag;
import cn.nukkit.potion.Effect;
import cn.nukkit.utils.Config;

import java.util.*;

/** ДонШоп: вкладки, покупка за койны, особые предметы с задержкой. */
public class Shop implements Listener {

    private static final String TAG = "donate_special";

    /** Названия зачарований -> id Bedrock. Добавляй свои при необходимости. */
    public static final Map<String, Integer> ENCH = new HashMap<>();
    static {
        ENCH.put("protection", 0); ENCH.put("fire_protection", 1); ENCH.put("feather_falling", 2);
        ENCH.put("blast_protection", 3); ENCH.put("projectile_protection", 4); ENCH.put("thorns", 5);
        ENCH.put("respiration", 6); ENCH.put("depth_strider", 7); ENCH.put("aqua_affinity", 8);
        ENCH.put("sharpness", 9); ENCH.put("smite", 10); ENCH.put("bane_of_arthropods", 11);
        ENCH.put("knockback", 12); ENCH.put("fire_aspect", 13); ENCH.put("looting", 14);
        ENCH.put("efficiency", 15); ENCH.put("silk_touch", 16); ENCH.put("unbreaking", 17);
        ENCH.put("fortune", 18); ENCH.put("power", 19); ENCH.put("punch", 20);
        ENCH.put("flame", 21); ENCH.put("infinity", 22); ENCH.put("mending", 26);
        ENCH.put("impaling", 29); ENCH.put("riptide", 30); ENCH.put("loyalty", 31);
        ENCH.put("channeling", 32); ENCH.put("multishot", 33); ENCH.put("piercing", 34);
        ENCH.put("quick_charge", 35);
    }

    private static class Entry {
        String id, name, material, special = "";
        int price, count = 1, cooldown;
        Map<String, Integer> enchants = new LinkedHashMap<>();
        List<String> lore = new ArrayList<>();
    }

    private static class Tab {
        String title;
        List<Entry> items = new ArrayList<>();
    }

    private final DonatePlugin plugin;
    private final List<Tab> tabs = new ArrayList<>();
    private boolean consume;
    private final Map<String, Long> cooldowns = new HashMap<>();

    public Shop(DonatePlugin plugin, Config cfg) {
        this.plugin = plugin;
        this.consume = U.b(cfg.get("consume_special"), true);
        for (Object t : U.l(cfg.get("tabs"))) {
            Map<String, Object> tm = U.m(t);
            Tab tab = new Tab();
            tab.title = U.s(tm.get("title"), "?");
            for (Object it : U.l(tm.get("items"))) {
                Map<String, Object> m = U.m(it);
                Entry e = new Entry();
                e.id = U.s(m.get("id"), "");
                e.name = U.s(m.get("name"), e.id);
                e.material = U.s(m.get("material"), "air");
                e.price = U.i(m.get("price"), 0);
                e.count = U.i(m.get("count"), 1);
                e.special = U.s(m.get("special"), "");
                e.cooldown = U.i(m.get("cooldown"), 0);
                for (Map.Entry<String, Object> en : U.m(m.get("enchants")).entrySet())
                    e.enchants.put(en.getKey(), U.i(en.getValue(), 1));
                for (Object l : U.l(m.get("lore"))) e.lore.add(String.valueOf(l));
                tab.items.add(e);
            }
            tabs.add(tab);
        }
    }

    // ---------------- меню ----------------

    public void open(Player p) {
        List<String> b = new ArrayList<>();
        for (Tab t : tabs) b.add(t.title);
        plugin.forms.simple(p, "§l§6ДонШоп", "Ваш баланс: §e" + plugin.store.get(p.getName()).coins + " койнов", b,
                idx -> { if (idx >= 0 && idx < tabs.size()) openTab(p, tabs.get(idx)); });
    }

    private void openTab(Player p, Tab tab) {
        List<String> b = new ArrayList<>();
        for (Entry e : tab.items) b.add(e.name + "\n§8" + e.price + " койнов");
        b.add("§7« Назад");
        plugin.forms.simple(p, tab.title, "Баланс: §e" + plugin.store.get(p.getName()).coins, b, idx -> {
            if (idx == tab.items.size()) { open(p); return; }
            if (idx < 0 || idx >= tab.items.size()) return;
            Entry e = tab.items.get(idx);
            StringBuilder d = new StringBuilder(e.name).append("\n\n§fЦена: §e").append(e.price).append(" койнов");
            for (Map.Entry<String, Integer> en : e.enchants.entrySet())
                d.append("\n§7- ").append(en.getKey()).append(" ").append(en.getValue());
            for (String l : e.lore) d.append("\n").append(l);
            plugin.forms.confirm(p, "Покупка", d.toString(), () -> buy(p, e));
        });
    }

    private void buy(Player p, Entry e) {
        Store.PD d = plugin.store.get(p.getName());
        if (d.coins < e.price) {
            p.sendMessage("§cНедостаточно койнов. Нужно " + e.price + ", у вас " + d.coins + ".");
            return;
        }
        Item item = build(e);
        if (item == null) {
            p.sendMessage("§cПредмет недоступен (ошибка конфигурации). Сообщите администрации.");
            return;
        }
        d.coins -= e.price;
        plugin.store.save();
        Item[] left = p.getInventory().addItem(item);
        for (Item l : left) p.getLevel().dropItem(p, l);
        p.sendMessage("§aВы купили " + e.name + "§a за " + e.price + " койнов. Баланс: " + d.coins);
        plugin.getLogger().info(p.getName() + " купил " + e.id + " за " + e.price);
    }

    /** Общая фабрика предметов (ДонШоп и киты). null, если предмет неизвестен. */
    public static Item make(String material, String name, int count, Map<String, Integer> enchants) {
        Item item;
        try {
            item = Item.fromString(material);
        } catch (Exception ex) {
            return null;
        }
        if (item == null || item.getId() == 0) return null;
        item.setCount(count);
        if (name != null && !name.isEmpty()) item.setCustomName(name);
        for (Map.Entry<String, Integer> en : enchants.entrySet()) {
            Integer id = ENCH.get(en.getKey());
            if (id == null) continue;
            Enchantment ench = Enchantment.getEnchantment(id);
            if (ench == null) continue;
            item.addEnchantment(ench.setLevel(en.getValue(), false));
        }
        return item;
    }

    private Item build(Entry e) {
        Item item = make(e.material, e.name, e.count, e.enchants);
        if (item == null) {
            plugin.getLogger().warning("Неизвестный предмет: " + e.material + " (shop.yml, id=" + e.id + ")");
            return null;
        }
        if (!e.lore.isEmpty()) item.setLore(e.lore.toArray(new String[0]));
        if (!e.special.isEmpty()) {
            CompoundTag tag = item.hasCompoundTag() ? item.getNamedTag() : new CompoundTag();
            tag.putString(TAG, e.special);
            tag.putInt("donate_cd", e.cooldown);
            item.setNamedTag(tag);
        }
        return item;
    }

    // ---------------- особые предметы ----------------

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != PlayerInteractEvent.Action.RIGHT_CLICK_AIR
                && e.getAction() != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) return;
        Item item = e.getItem();
        if (item == null || !item.hasCompoundTag()) return;
        CompoundTag tag = item.getNamedTag();
        if (!tag.contains(TAG)) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (!plugin.isAuthed(p)) return;
        String sp = tag.getString(TAG);
        int cd = tag.getInt("donate_cd");
        String key = p.getUniqueId() + ":" + sp;
        long now = System.currentTimeMillis();
        Long until = cooldowns.get(key);
        if (until != null && until > now) {
            p.sendMessage("§cПодождите ещё " + ((until - now + 999) / 1000) + " сек.");
            return;
        }
        if (!apply(p, sp)) return;
        cooldowns.put(key, now + cd * 1000L);
        if (consume) {
            Item hand = p.getInventory().getItemInHand();
            hand.setCount(hand.getCount() - 1);
            p.getInventory().setItemInHand(hand.getCount() > 0 ? hand : Item.get(0));
        }
    }

    /** Не даём «съесть» особую морковь/яблоко стандартным способом. */
    @EventHandler
    public void onConsume(PlayerItemConsumeEvent e) {
        Item item = e.getItem();
        if (item != null && item.hasCompoundTag() && item.getNamedTag().contains(TAG)) e.setCancelled(true);
    }

    private boolean apply(Player p, String sp) {
        switch (sp) {
            case "heal":
                p.setHealth(p.getMaxHealth());
                p.sendMessage("§aЗдоровье восстановлено.");
                return true;
            case "feed":
                p.getFoodData().setLevel(20, 20f);
                p.sendMessage("§aГолод восстановлен.");
                return true;
            case "levitate":
                p.addEffect(Effect.getEffect(Effect.LEVITATION).setDuration(15 * 20).setAmplifier(0));
                return true;
            case "speed":
                p.addEffect(Effect.getEffect(Effect.SPEED).setDuration(30 * 20).setAmplifier(2));
                return true;
            case "demeter":
                p.addEffect(Effect.getEffect(Effect.REGENERATION).setDuration(5 * 20).setAmplifier(1));
                p.addEffect(Effect.getEffect(Effect.ABSORPTION).setDuration(120 * 20).setAmplifier(0));
                p.addEffect(Effect.getEffect(Effect.DAMAGE_RESISTANCE).setDuration(300 * 20).setAmplifier(0));
                p.addEffect(Effect.getEffect(Effect.FIRE_RESISTANCE).setDuration(300 * 20).setAmplifier(0));
                p.addEffect(Effect.getEffect(Effect.STRENGTH).setDuration(30 * 20).setAmplifier(3));
                p.addEffect(Effect.getEffect(Effect.SPEED).setDuration(30 * 20).setAmplifier(3));
                return true;
            case "deimos":
                return deimos(p);
            default:
                return false;
        }
    }

    /** Телепорт сквозь стену до 10 блоков: ищем первую свободную пару блоков за препятствием. */
    private boolean deimos(Player p) {
        Vector3 dir = p.getDirectionVector();
        double ex = p.x, ey = p.y + p.getEyeHeight(), ez = p.z;
        boolean seenSolid = false;
        for (int d = 1; d <= 10; d++) {
            int bx = (int) Math.floor(ex + dir.x * d);
            int by = (int) Math.floor(ey + dir.y * d);
            int bz = (int) Math.floor(ez + dir.z * d);
            Block feet = p.getLevel().getBlock(new Vector3(bx, by - 1, bz));
            Block head = p.getLevel().getBlock(new Vector3(bx, by, bz));
            boolean solid = feet.isSolid() || head.isSolid();
            if (solid) {
                seenSolid = true;
            } else if (seenSolid) {
                p.teleport(new Vector3(bx + 0.5, by - 1, bz + 0.5));
                p.sendMessage("§5Вы прошли сквозь стену.");
                return true;
            }
        }
        p.sendMessage("§cСлишком далеко или нет стены перед вами.");
        return false;
    }
}
