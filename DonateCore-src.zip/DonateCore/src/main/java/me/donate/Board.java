package me.donate;

import cn.nukkit.Player;
import cn.nukkit.command.CommandSender;
import cn.nukkit.network.protocol.RemoveObjectivePacket;
import cn.nukkit.network.protocol.SetDisplayObjectivePacket;
import cn.nukkit.network.protocol.SetScorePacket;
import cn.nukkit.utils.Config;

import java.util.*;

/**
 * Скорборд справа (sidebar): ник, привилегия, префикс, монеты, койны, онлайн, клан и свои строки.
 * Всё берётся из config.yml -> scoreboard. Отправляется пакетами, поэтому не зависит от версии scoreboard API ядра.
 */
public class Board {

    private static final String OBJ = "donatecore";

    private final DonatePlugin pl;
    private final boolean enabled;
    private final String title;
    private final List<String> lines = new ArrayList<>();
    private final Set<UUID> hidden = new HashSet<>();
    private final Map<UUID, Integer> shown = new HashMap<>(); // хэш последнего отправленного набора строк

    public Board(DonatePlugin pl, Config cfg) {
        this.pl = pl;
        Map<String, Object> c = U.m(cfg.get("scoreboard"));
        enabled = U.b(c.get("enabled"), true);
        title = U.s(c.get("title"), "§e§lСервер");
        for (Object o : U.l(c.get("lines"))) lines.add(String.valueOf(o));
        int ticks = Math.max(10, U.i(c.get("update_ticks"), 40));
        if (enabled) pl.getServer().getScheduler().scheduleRepeatingTask(pl, this::tick, ticks);
    }

    public boolean command(CommandSender s) {
        if (!(s instanceof Player)) { s.sendMessage("Только в игре."); return true; }
        Player p = (Player) s;
        if (hidden.remove(p.getUniqueId())) {
            p.sendMessage("§aТабло включено.");
        } else {
            hidden.add(p.getUniqueId());
            remove(p);
            p.sendMessage("§cТабло скрыто. Вернуть: /sb");
        }
        return true;
    }

    public void forget(Player p) {
        shown.remove(p.getUniqueId());
        hidden.remove(p.getUniqueId());
    }

    private void tick() {
        for (Player p : pl.getServer().getOnlinePlayers().values()) {
            if (!p.isOnline() || hidden.contains(p.getUniqueId())) continue;
            if (!pl.isAuthed(p)) { if (shown.containsKey(p.getUniqueId())) remove(p); continue; }
            update(p);
        }
    }

    // ------------------------------------------------------------ подстановки

    private String colorOf(String prefix) {
        int i = prefix.indexOf('[');
        return i > 0 ? prefix.substring(0, i) : "§f";
    }

    /** 1800 -> "1.8 тыс.", 2500000 -> "2.5 млн" */
    private String abbr(long v) {
        if (v >= 1_000_000) return one(v / 1_000_000.0) + " млн";
        if (v >= 1000) return one(v / 1000.0) + " тыс.";
        return String.valueOf(v);
    }

    private String one(double x) {
        String t = String.format(Locale.ROOT, "%.1f", x);
        return t.endsWith(".0") ? t.substring(0, t.length() - 2) : t;
    }

    private String render(Player p, String line) {
        Store.PD d = pl.store.get(p.getName());
        Ranks.Rank r = pl.displayRank(p);
        String rank = r == null ? "§7Игрок" : colorOf(r.prefix) + r.name;
        Cosmetics.Cos c = pl.cosmetics.get(d.activeCosmetic);
        String prefix = c == null ? "§7нет" : c.prefix.replace("[", "").replace("]", "");
        return line.replace("{player}", p.getName())
                .replace("{rank}", rank)
                .replace("{prefix}", prefix)
                .replace("{money}", abbr(d.money))
                .replace("{coins}", abbr(d.coins))
                .replace("{online}", String.valueOf(pl.getServer().getOnlinePlayers().size()))
                .replace("{max}", String.valueOf(pl.getServer().getMaxPlayers()))
                .replace("{clan}", pl.clans.clanLabel(p));
    }

    // ------------------------------------------------------------ пакеты

    private void update(Player p) {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            String t = render(p, lines.get(i));
            // имена строк в скорборде должны быть уникальными - добавляем невидимый хвост
            StringBuilder sb = new StringBuilder(t);
            for (int k = 0; k < i; k++) sb.append("§r");
            out.add(sb.toString());
        }
        int hash = Objects.hash(out.toArray());
        Integer prev = shown.get(p.getUniqueId());
        if (prev != null && prev == hash) return;
        boolean first = prev == null;
        shown.put(p.getUniqueId(), hash);

        if (!first) {
            RemoveObjectivePacket rm = new RemoveObjectivePacket();
            rm.objectiveName = OBJ;
            p.dataPacket(rm);
        }
        SetDisplayObjectivePacket disp = new SetDisplayObjectivePacket();
        disp.displaySlot = "sidebar";
        disp.objectiveName = OBJ;
        disp.displayName = title;
        disp.criteriaName = "dummy";
        disp.sortOrder = 1; // по убыванию: верхняя строка = наибольший счёт
        p.dataPacket(disp);

        SetScorePacket sc = new SetScorePacket();
        sc.action = SetScorePacket.Action.SET;
        int n = out.size();
        for (int i = 0; i < n; i++)
            sc.infos.add(new SetScorePacket.ScoreInfo(i + 1, OBJ, n - i, out.get(i)));
        p.dataPacket(sc);
    }

    private void remove(Player p) {
        if (shown.remove(p.getUniqueId()) == null) return;
        RemoveObjectivePacket rm = new RemoveObjectivePacket();
        rm.objectiveName = OBJ;
        p.dataPacket(rm);
    }
}
