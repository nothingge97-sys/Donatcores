package me.donate;

import cn.nukkit.Player;
import cn.nukkit.block.Block;
import cn.nukkit.command.CommandSender;
import cn.nukkit.entity.Entity;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.block.BlockBreakEvent;
import cn.nukkit.event.block.BlockPlaceEvent;
import cn.nukkit.event.entity.EntityDamageByEntityEvent;
import cn.nukkit.event.entity.EntityDamageEvent;
import cn.nukkit.event.inventory.InventoryPickupItemEvent;
import cn.nukkit.event.player.*;
import cn.nukkit.inventory.FurnaceRecipe;
import cn.nukkit.item.Item;
import cn.nukkit.level.Level;
import cn.nukkit.level.Location;
import cn.nukkit.math.Vector3;
import cn.nukkit.network.protocol.PlaySoundPacket;
import cn.nukkit.potion.Effect;
import cn.nukkit.utils.Config;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

/** Остальные команды из списка привилегий + наказания, варпы, киты, /set. */
public class Cmds implements Listener {

    private final DonatePlugin pl;
    public final Punish punish;
    private final Config warpsCfg, kitsCfg;
    private final Map<String, Map<String, Object>> warps = new LinkedHashMap<>();

    private final Set<UUID> god = new HashSet<>(), noHunger = new HashSet<>(), vanished = new HashSet<>(),
            noPickup = new HashSet<>(), tpOff = new HashSet<>(), tpInfo = new HashSet<>(), skinLocked = new HashSet<>();
    private final Map<UUID, Location> back = new HashMap<>();
    private final Map<UUID, Runnable> skinRestore = new HashMap<>();
    private final Map<String, Long> lastAct = new HashMap<>();
    private final Map<UUID, Long> joined = new HashMap<>();
    private final Map<UUID, Vector3[]> sel = new HashMap<>();
    private final Map<UUID, List<Block>> undo = new HashMap<>();
    private final SimpleDateFormat fmt = new SimpleDateFormat("dd.MM HH:mm");

    private static final Map<String, String> GIFTS = new LinkedHashMap<>();
    static {
        GIFTS.put("givefly", "fly"); GIFTS.put("givevip", "vip"); GIFTS.put("givepremium", "premium");
        GIFTS.put("giveultra", "ultra"); GIFTS.put("givecreative", "creative");
        GIFTS.put("givemoder", "moder"); GIFTS.put("giveyoutube", "youtuber");
    }

    public Cmds(DonatePlugin pl) {
        this.pl = pl;
        File d = pl.getDataFolder();
        punish = new Punish(new File(d, "punish.yml"));
        kitsCfg = new Config(new File(d, "kits.yml"), Config.YAML);
        warpsCfg = new Config(new File(d, "warps.yml"), Config.YAML);
        for (Map.Entry<String, Object> e : warpsCfg.getAll().entrySet()) warps.put(e.getKey(), U.m(e.getValue()));
    }

    // ============================================================ утилиты

    private boolean isOwnerOrConsole(CommandSender s) {
        return !(s instanceof Player) || pl.isOwner((Player) s);
    }

    private boolean other(CommandSender s, String c) {
        return s.isOp() || s.hasPermission("donate.cmd." + c + ".other");
    }

    /** Владелец, консоль и ранги с permanent_punish (Хелпер, Модератор, Создатель): без лимитов и задержек. */
    private boolean unlimited(CommandSender s) {
        if (isOwnerOrConsole(s)) return true;
        Ranks.Rank r = pl.rankOf((Player) s);
        return r != null && r.permanent;
    }

    private int limit(CommandSender s, String key) {
        if (unlimited(s)) return Integer.MAX_VALUE;
        return pl.getLimit((Player) s, key, 0);
    }

    /** Цель команды: сам игрок или указанный (нужно право .other). */
    private Player target(CommandSender s, String c, String[] a, int idx) {
        if (a.length > idx) {
            if (!other(s, c)) { s.sendMessage("§cНет прав на эту команду для другого игрока."); return null; }
            Player t = pl.getServer().getPlayer(a[idx]);
            if (t == null) s.sendMessage("§cИгрок не найден.");
            return t;
        }
        if (s instanceof Player) return (Player) s;
        s.sendMessage("Укажите игрока.");
        return null;
    }

    private Player online(CommandSender s, String name) {
        Player t = pl.getServer().getPlayer(name);
        if (t == null) s.sendMessage("§cИгрок не найден (должен быть онлайн).");
        return t;
    }

    private String date(long ms) {
        return ms == 0 ? "навсегда" : fmt.format(new Date(ms));
    }

    private String dur(long ms) {
        long m = ms / 60000;
        return m >= 60 ? (m / 60) + " ч " + (m % 60) + " мин" : m + " мин";
    }

    private int orderOf(String name) {
        if (pl.ownerLevel(name) > 0) return 2000 + pl.ownerLevel(name);
        Ranks.Rank r = pl.ranks.byId(pl.store.get(name).rank);
        return r == null ? -1 : r.order;
    }

    private boolean toggle(Set<UUID> set, Player p) {
        if (!set.remove(p.getUniqueId())) { set.add(p.getUniqueId()); return true; }
        return false;
    }

    /** Можно ли применять наказание к игроку: иммунитет, владельцы, ранг не ниже. */
    private boolean canTouch(CommandSender s, String targetName) {
        if (!(s instanceof Player)) return true;
        // владельцы: наказывать владельца может только владелец с БОЛЬШИМ приоритетом (порядок в config.yml -> owners)
        int tl = pl.ownerLevel(targetName);
        int sl = pl.isOwner((Player) s) ? pl.ownerLevel(s.getName()) : 0;
        if (tl > 0) {
            if (sl > tl || s.getName().equalsIgnoreCase(targetName)) return true;
            s.sendMessage("§cНе удалось выполнить команду.");
            return false;
        }
        if (sl > 0) return true;
        Player on = pl.getServer().getPlayerExact(targetName);
        if (on != null && (pl.isOwner(on) || pl.hasImmunity(on))) {
            s.sendMessage("§cЭтот игрок имеет иммунитет от наказаний.");
            return false;
        }
        if (orderOf(targetName) >= orderOf(s.getName())) {
            s.sendMessage("§cВы не можете наказывать игрока с равной или более высокой привилегией.");
            return false;
        }
        return true;
    }

    /** Задержка между наказаниями (в минутах из лимитов). */
    private boolean delayOk(CommandSender s, String type) {
        if (unlimited(s)) return true;
        long delay = limit(s, type + "_delay") * 60000L;
        String key = s.getName().toLowerCase() + ":" + type;
        long now = System.currentTimeMillis();
        Long last = lastAct.get(key);
        if (last != null && last + delay > now) {
            s.sendMessage("§cПодождите ещё " + dur(last + delay - now) + " перед следующим действием.");
            return false;
        }
        lastAct.put(key, now);
        return true;
    }

    private long parseMinutes(CommandSender s, String text, int max) {
        try {
            long m = Long.parseLong(text);
            if (m <= 0) { s.sendMessage("§cУкажите время в минутах (больше 0)."); return -1; }
            if (m > max) { s.sendMessage("§cВаш максимум за один раз: " + max + " мин."); return -1; }
            return m;
        } catch (NumberFormatException e) {
            s.sendMessage("§cВремя должно быть числом (минуты).");
            return -1;
        }
    }

    private String reasonFrom(String[] a, int from) {
        return a.length > from ? String.join(" ", Arrays.copyOfRange(a, from, a.length)) : "не указана";
    }

    // ============================================================ обработка команд

    public boolean handle(CommandSender s, String c, String[] a) {
        if (GIFTS.containsKey(c)) return gift(s, c, a);
        switch (c) {
            case "pos": return pos(s, a);
            case "pickup": return selfToggle(s, noPickup, "Подбор предметов", true);
            case "hunger": return selfToggle(s, noHunger, "Трата голода", true);
            case "god": return god(s, a);
            case "tptoggle": return selfToggle(s, tpOff, "Телепортация к вам", true);
            case "tpinfo": return selfToggle(s, tpInfo, "Уведомления о телепортации", false);
            case "skintoggle": return selfToggle(s, skinLocked, "Защита скина", false);
            case "back": return back(s);
            case "kit": return kit(s, a);
            case "milk": return milk(s, a);
            case "cook": return cook(s);
            case "repair": return repair(s, false, a);
            case "repairall": return repair(s, true, a);
            case "statistics": return stats(s, a);
            case "suicide": return suicide(s);
            case "skin": return skin(s, a);
            case "delskin": return delskin(s);
            case "top": return top(s);
            case "speed": return speed(s, a);
            case "size": return size(s, a);
            case "rptp": return rptp(s);
            case "tpme": return tpme(s, a);
            case "tppos": return tppos(s, a);
            case "spawn": return spawn(s, a);
            case "near": return near(s, a);
            case "whois": return whois(s, a);
            case "player": return playerMenu(s, a);
            case "chatclear": return chatclear(s);
            case "vanish": return vanish(s);
            case "nightvision": return nightvision(s);
            case "itemrename": return rename(s, a);
            case "invsee": return invsee(s, a);
            case "set": return set(s, a);
            case "undo": return undo(s);
            case "setinfo": return setinfo(s);
            case "warp": return warp(s, a);
            case "setwarp": return setwarp(s, a);
            case "delwarp": return delwarp(s, a);
            case "warpinfo": return warpinfo(s, a);
            case "agl": return agl(s);
            case "badnicks": return badnicks(s);
            case "seemoney": return seemoney(s, a);
            case "burn": return burn(s, a);
            case "shock": return shock(s, a);
            case "scream": return scream(s, a);
            case "fakeop": return fakeop(s, a);
            case "ban": return ban(s, a, "ban");
            case "mute": return ban(s, a, "mute");
            case "unban": return unban(s, a, "ban");
            case "unmute": return unban(s, a, "mute");
            case "kick": return kick(s, a);
            case "banlist": return list(s, "ban", false);
            case "mutelist": return list(s, "mute", false);
            case "unbanlist": return list(s, "ban", true);
            case "unmutelist": return list(s, "mute", true);
            case "kicklist": return kicklist(s);
            case "bansee": return see(s, a, "ban");
            case "mutesee": return see(s, a, "mute");
            default: return pl.extra != null && pl.extra.handle(s, c, a);
        }
    }

    // ------------------------------------------------------------ простые

    private boolean pos(CommandSender s, String[] a) {
        Player t = (a.length > 0 && other(s, "pos")) ? pl.getServer().getPlayer(a[0])
                : (s instanceof Player ? (Player) s : null);
        if (t == null) { s.sendMessage("§cИгрок не найден."); return true; }
        s.sendMessage("§eПозиция " + t.getName() + ": §f" + t.getFloorX() + ", " + t.getFloorY() + ", " + t.getFloorZ()
                + " §7(" + t.getLevel().getName() + ")");
        return true;
    }

    private boolean selfToggle(CommandSender s, Set<UUID> set, String title, boolean onMeansOff) {
        if (!(s instanceof Player)) { s.sendMessage("Только в игре."); return true; }
        Player p = (Player) s;
        boolean added = toggle(set, p);
        // onMeansOff: наличие в наборе = функция ВЫКЛЮЧЕНА (pickup, hunger, tptoggle)
        boolean enabled = onMeansOff ? !added : added;
        p.sendMessage("§e" + title + ": " + (enabled ? "§aвключено" : "§cвыключено"));
        return true;
    }

    private boolean god(CommandSender s, String[] a) {
        Player t = target(s, "god", a, 0);
        if (t == null) return true;
        boolean on = toggle(god, t);
        t.sendMessage(on ? "§aБессмертие включено." : "§cБессмертие выключено.");
        if (t != s) s.sendMessage("§aБессмертие для " + t.getName() + ": " + (on ? "вкл" : "выкл"));
        return true;
    }

    private boolean back(CommandSender s) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        Location l = back.get(p.getUniqueId());
        if (l == null) { p.sendMessage("§cНет сохранённой позиции."); return true; }
        p.teleport(l);
        p.sendMessage("§aВы вернулись.");
        return true;
    }

    private boolean milk(CommandSender s, String[] a) {
        Player t = target(s, "milk", a, 0);
        if (t == null) return true;
        t.removeAllEffects();
        t.sendMessage("§aВсе эффекты сняты.");
        return true;
    }

    private boolean cook(CommandSender s) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        Item hand = p.getInventory().getItemInHand();
        FurnaceRecipe r = hand == null ? null : pl.getServer().getCraftingManager().matchFurnaceRecipe(hand);
        if (r == null) { p.sendMessage("§cЭтот предмет нельзя приготовить."); return true; }
        Item res = r.getResult().clone();
        res.setCount(res.getCount() * hand.getCount());
        p.getInventory().setItemInHand(res);
        p.sendMessage("§aПредмет приготовлен.");
        return true;
    }

    private boolean repair(CommandSender s, boolean all, String[] a) {
        Player t = all ? target(s, "repairall", a, 0) : (s instanceof Player ? (Player) s : null);
        if (t == null) return true;
        if (!all) {
            Item it = t.getInventory().getItemInHand();
            if (it != null && (it.isTool() || it.isArmor())) {
                it.setDamage(0);
                t.getInventory().setItemInHand(it);
                t.sendMessage("§aПредмет починен.");
            } else t.sendMessage("§cЭтот предмет нельзя починить.");
            return true;
        }
        for (Map.Entry<Integer, Item> e : new HashMap<>(t.getInventory().getContents()).entrySet()) {
            Item it = e.getValue();
            if (it != null && (it.isTool() || it.isArmor())) { it.setDamage(0); t.getInventory().setItem(e.getKey(), it); }
        }
        for (int i = 0; i < 4; i++) {
            Item it = t.getInventory().getArmorItem(i);
            if (it != null && it.isArmor()) { it.setDamage(0); t.getInventory().setArmorItem(i, it); }
        }
        t.sendMessage("§aВсе вещи починены.");
        return true;
    }

    private boolean suicide(CommandSender s) {
        if (s instanceof Player) ((Player) s).kill();
        return true;
    }

    private boolean top(CommandSender s) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        int y = p.getLevel().getHighestBlockAt(p.getFloorX(), p.getFloorZ());
        p.teleport(new Vector3(p.x, y + 1, p.z));
        p.sendMessage("§aВы на верхнем блоке.");
        return true;
    }

    private boolean speed(CommandSender s, String[] a) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        if (a.length < 1) { p.sendMessage("§c/speed <1-5> (1 = обычная)"); return true; }
        try {
            double v = Double.parseDouble(a[0]);
            if (v < 1 || v > 5) { p.sendMessage("§cДопустимо от 1 до 5."); return true; }
            p.setMovementSpeed((float) (0.1 * v));
            p.sendMessage("§aСкорость: x" + v);
        } catch (NumberFormatException e) { p.sendMessage("§cЧисло неверное."); }
        return true;
    }

    private boolean size(CommandSender s, String[] a) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        if (a.length < 1) { p.sendMessage("§c/size <0.3-3> (1 = обычный)"); return true; }
        try {
            double v = Double.parseDouble(a[0]);
            if (v < 0.3 || v > 3) { p.sendMessage("§cДопустимо от 0.3 до 3."); return true; }
            p.setScale((float) v);
            p.sendMessage("§aРазмер: " + v);
        } catch (NumberFormatException e) { p.sendMessage("§cЧисло неверное."); }
        return true;
    }

    private boolean nightvision(CommandSender s) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        if (p.hasEffect(Effect.NIGHT_VISION)) {
            p.removeEffect(Effect.NIGHT_VISION);
            p.sendMessage("§cНочное зрение выключено.");
        } else {
            p.addEffect(Effect.getEffect(Effect.NIGHT_VISION).setDuration(20 * 3600 * 24).setVisible(false));
            p.sendMessage("§aНочное зрение включено.");
        }
        return true;
    }

    private boolean vanish(CommandSender s) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        boolean on = toggle(vanished, p);
        for (Player o : pl.getServer().getOnlinePlayers().values()) {
            if (o == p) continue;
            if (on && !o.hasPermission("donate.cmd.vanish")) o.hidePlayer(p);
            else o.showPlayer(p);
        }
        p.sendMessage(on ? "§aВы невидимы." : "§cВы снова видимы.");
        return true;
    }

    private boolean rename(CommandSender s, String[] a) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        if (a.length < 1) { p.sendMessage("§c/itemrename <название> (цвета через &)"); return true; }
        Item it = p.getInventory().getItemInHand();
        if (it == null || it.getId() == 0) { p.sendMessage("§cВозьмите предмет в руку."); return true; }
        String name = String.join(" ", a).replace('&', '§');
        if (name.length() > 48) { p.sendMessage("§cСлишком длинное название."); return true; }
        it.setCustomName(name);
        p.getInventory().setItemInHand(it);
        p.sendMessage("§aПредмет переименован.");
        return true;
    }

    private boolean chatclear(CommandSender s) {
        for (Player o : pl.getServer().getOnlinePlayers().values())
            for (int i = 0; i < 100; i++) o.sendMessage(" ");
        pl.getServer().broadcastMessage("§7Чат очищен администратором.");
        return true;
    }

    // ------------------------------------------------------------ скины

    private boolean skin(CommandSender s, String[] a) {
        if (!(s instanceof Player) || a.length < 1) { s.sendMessage("§c/skin <игрок>"); return true; }
        Player p = (Player) s;
        Player t = online(s, a[0]);
        if (t == null) return true;
        if (skinLocked.contains(t.getUniqueId()) && !pl.isOwner(p)) { s.sendMessage("§cИгрок защитил скин от копирования."); return true; }
        var orig = p.getSkin();
        skinRestore.putIfAbsent(p.getUniqueId(), () -> p.setSkin(orig));
        p.setSkin(t.getSkin());
        p.sendMessage("§aСкин скопирован. Вернуть: /delskin");
        return true;
    }

    private boolean delskin(CommandSender s) {
        if (!(s instanceof Player)) return true;
        Runnable r = skinRestore.remove(((Player) s).getUniqueId());
        if (r == null) { s.sendMessage("§cУ вас нет изменённого скина."); return true; }
        r.run();
        s.sendMessage("§aСкин возвращён.");
        return true;
    }

    // ------------------------------------------------------------ информация

    private boolean stats(CommandSender s, String[] a) {
        String name = a.length > 0 ? a[0] : s.getName();
        if (a.length > 0 && !pl.store.exists(name)) { s.sendMessage("§cИгрок не найден."); return true; }
        Store.PD d = pl.store.get(name);
        long play = d.playMs;
        Player on = pl.getServer().getPlayerExact(name);
        if (on != null && joined.containsKey(on.getUniqueId())) play += System.currentTimeMillis() - joined.get(on.getUniqueId());
        s.sendMessage("§eСтатистика " + name + ":\n§7Время в игре: §f" + dur(play) + "\n§7Убийств: §f" + d.kills
                + "\n§7Смертей: §f" + d.deaths + "\n§7Сломано блоков: §f" + d.broken + "\n§7Поставлено блоков: §f" + d.placed);
        return true;
    }

    private boolean whois(CommandSender s, String[] a) {
        if (a.length < 1) { s.sendMessage("§c/whois <игрок>"); return true; }
        Player t = online(s, a[0]);
        if (t == null) return true;
        Ranks.Rank r = pl.displayRank(t);
        s.sendMessage("§e" + t.getName() + "\n§7Привилегия: §f" + (r == null ? "нет" : r.name)
                + "\n§7Койны: §f" + pl.store.get(t.getName()).coins + "\n§7Монеты: §f" + pl.store.get(t.getName()).money
                + "\n§7IP: §f" + t.getAddress() + "\n§7Пинг: §f" + t.getPing()
                + "\n§7Мир: §f" + t.getLevel().getName() + " (" + t.getFloorX() + ", " + t.getFloorY() + ", " + t.getFloorZ() + ")"
                + "\n§7Здоровье: §f" + (int) t.getHealth() + "/" + (int) t.getMaxHealth()
                + "\n§7Режим: §f" + t.getGamemode());
        return true;
    }

    private boolean near(CommandSender s, String[] a) {
        Player t = a.length > 0 ? (other(s, "near") ? online(s, a[0]) : null) : (s instanceof Player ? (Player) s : null);
        if (t == null) { if (a.length > 0) s.sendMessage("§cНет прав или игрок не найден."); return true; }
        StringBuilder sb = new StringBuilder("§eРядом с " + t.getName() + " (100 блоков):");
        int n = 0;
        for (Player o : pl.getServer().getOnlinePlayers().values()) {
            if (o == t || o.getLevel() != t.getLevel() || vanished.contains(o.getUniqueId())) continue;
            double d = o.distance(t);
            if (d <= 100) { sb.append("\n§7").append(o.getName()).append(": §f").append((int) d).append(" м"); n++; }
        }
        s.sendMessage(n == 0 ? "§7Рядом никого нет." : sb.toString());
        return true;
    }

    private boolean seemoney(CommandSender s, String[] a) {
        if (a.length < 1) { s.sendMessage("§c/seemoney <игрок>"); return true; }
        if (!pl.store.exists(a[0])) { s.sendMessage("§cИгрок не найден."); return true; }
        Store.PD d = pl.store.get(a[0]);
        s.sendMessage("§e" + a[0] + ": §f" + d.money + " монет, " + d.coins + " койнов");
        return true;
    }

    private boolean agl(CommandSender s) {
        StringBuilder sb = new StringBuilder("§eИгроки со сменёнными префиксами:");
        int n = 0;
        for (Map.Entry<String, Store.PD> e : pl.store.all().entrySet()) {
            Store.PD d = e.getValue();
            if (!d.activePref.isEmpty() || !d.activeCosmetic.isEmpty()) {
                sb.append("\n§7").append(e.getKey()).append(": §fпривилегия=").append(d.activePref.isEmpty() ? "по умолч." : d.activePref)
                        .append(", косметика=").append(d.activeCosmetic.isEmpty() ? "-" : d.activeCosmetic);
                n++;
            }
        }
        s.sendMessage(n == 0 ? "§7Таких игроков нет." : sb.toString());
        return true;
    }

    private boolean badnicks(CommandSender s) {
        StringBuilder sb = new StringBuilder("§eИгроки со сложными никами:");
        int n = 0;
        for (Player o : pl.getServer().getOnlinePlayers().values()) {
            if (!o.getName().matches("[A-Za-z0-9_ ]{3,16}")) { sb.append("\n§7").append(o.getName()); n++; }
        }
        s.sendMessage(n == 0 ? "§7Таких игроков нет." : sb.toString());
        return true;
    }

    private boolean invsee(CommandSender s, String[] a) {
        if (!(s instanceof Player) || a.length < 1) { s.sendMessage("§c/invsee <игрок>"); return true; }
        Player t = online(s, a[0]);
        if (t == null) return true;
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Integer, Item> e : new TreeMap<>(t.getInventory().getContents()).entrySet()) {
            Item it = e.getValue();
            if (it != null && it.getId() != 0)
                sb.append("§7[").append(e.getKey()).append("] §f").append(it.hasCustomName() ? it.getCustomName() : it.getName())
                        .append(" x").append(it.getCount()).append("\n");
        }
        pl.forms.simple((Player) s, "Инвентарь " + t.getName(), sb.length() == 0 ? "Пусто" : sb.toString(),
                Collections.singletonList("Закрыть"), i -> { });
        return true;
    }

    // ------------------------------------------------------------ телепорты

    private boolean rptp(CommandSender s) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        List<Player> c = new ArrayList<>();
        for (Player o : pl.getServer().getOnlinePlayers().values())
            if (o != p && !tpOff.contains(o.getUniqueId()) && !vanished.contains(o.getUniqueId())) c.add(o);
        if (c.isEmpty()) { p.sendMessage("§cНет подходящих игроков."); return true; }
        Player t = c.get(new Random().nextInt(c.size()));
        p.teleport(t);
        p.sendMessage("§aВы телепортированы к " + t.getName());
        return true;
    }

    private boolean tpme(CommandSender s, String[] a) {
        if (!(s instanceof Player) || a.length < 1) { s.sendMessage("§c/tpme <игрок>"); return true; }
        Player p = (Player) s;
        Player t = online(s, a[0]);
        if (t == null) return true;
        if (tpOff.contains(t.getUniqueId()) && !pl.isOwner(p)) { s.sendMessage("§cИгрок отключил телепортацию."); return true; }
        t.teleport(p);
        t.sendMessage("§eВас телепортировал " + p.getName());
        return true;
    }

    private boolean tppos(CommandSender s, String[] a) {
        if (!(s instanceof Player) || a.length < 3) { s.sendMessage("§c/tppos <x> <y> <z>"); return true; }
        try {
            ((Player) s).teleport(new Vector3(Double.parseDouble(a[0]), Double.parseDouble(a[1]), Double.parseDouble(a[2])));
        } catch (NumberFormatException e) { s.sendMessage("§cКоординаты неверные."); }
        return true;
    }

    private boolean spawn(CommandSender s, String[] a) {
        Player t = target(s, "spawn", a, 0);
        if (t == null) return true;
        Location sp = Location.fromObject(t.getLevel().getSafeSpawn(), t.getLevel());
        if (t == s) pl.tele.go(t, sp, "спавн");
        else { t.teleport(sp); t.sendMessage("§aВас телепортировали на спавн."); }
        return true;
    }

    private boolean playerMenu(CommandSender s, String[] a) {
        if (!(s instanceof Player) || a.length < 1) { s.sendMessage("§c/player <игрок>"); return true; }
        Player t = online(s, a[0]);
        if (t == null) return true;
        String n = t.getName();
        String[][] acts = {{"Информация", "whois " + n}, {"Телепорт к игроку", "tp " + s.getName() + " " + n},
                {"Телепортировать ко мне", "tpme " + n}, {"Исцелить", "heal " + n}, {"Накормить", "feed " + n}};
        List<String> b = new ArrayList<>();
        for (String[] x : acts) b.add(x[0]);
        pl.forms.simple((Player) s, "Игрок " + n, "Выберите действие (права проверяются):", b, idx -> {
            if (idx >= 0 && idx < acts.length) pl.getServer().dispatchCommand(s, acts[idx][1]);
        });
        return true;
    }

    // ------------------------------------------------------------ шоу-команды

    private boolean burn(CommandSender s, String[] a) {
        if (a.length < 1) { s.sendMessage("§c/burn <игрок> [сек]"); return true; }
        Player t = online(s, a[0]);
        if (t == null || !canTouch(s, t.getName())) return true;
        int sec = 5;
        try { if (a.length > 1) sec = Math.max(1, Math.min(30, Integer.parseInt(a[1]))); } catch (NumberFormatException ignored) { }
        t.setOnFire(sec);
        s.sendMessage("§aИгрок подожжён.");
        return true;
    }

    private boolean shock(CommandSender s, String[] a) {
        if (a.length < 1) { s.sendMessage("§c/shock <игрок>"); return true; }
        Player t = online(s, a[0]);
        if (t == null || !canTouch(s, t.getName())) return true;
        Entity l = Entity.createEntity("Lightning", t);
        if (l != null) l.spawnToAll();
        s.sendMessage("§aМолния!");
        return true;
    }

    private boolean scream(CommandSender s, String[] a) {
        if (a.length < 1) { s.sendMessage("§c/scream <игрок>"); return true; }
        Player t = online(s, a[0]);
        if (t == null || !canTouch(s, t.getName())) return true;
        PlaySoundPacket pk = new PlaySoundPacket();
        pk.name = "mob.endermen.scream";
        pk.x = t.getFloorX(); pk.y = t.getFloorY(); pk.z = t.getFloorZ();
        pk.volume = 1f; pk.pitch = 0.6f;
        t.dataPacket(pk);
        t.addEffect(Effect.getEffect(Effect.BLINDNESS).setDuration(60));
        t.addEffect(Effect.getEffect(Effect.NAUSEA).setDuration(100));
        t.sendTitle("§4§lБУУУ!", "", 5, 20, 10);
        s.sendMessage("§aИгрок напуган.");
        return true;
    }

    private boolean fakeop(CommandSender s, String[] a) {
        if (a.length < 1) { s.sendMessage("§c/fakeop <игрок>"); return true; }
        Player t = online(s, a[0]);
        if (t == null || !canTouch(s, t.getName())) return true;
        t.sendMessage("§7Made " + t.getName() + " a server operator");
        s.sendMessage("§aШутка отправлена.");
        return true;
    }

    // ------------------------------------------------------------ подарки

    private boolean gift(CommandSender s, String c, String[] a) {
        if (a.length < 1) { s.sendMessage("§c/" + c + " <ник>"); return true; }
        Ranks.Rank gifted = pl.ranks.donate.get(GIFTS.get(c));
        if (gifted == null) { s.sendMessage("§cПривилегия не найдена в ranks.yml."); return true; }
        if (!pl.store.exists(a[0]) && pl.getServer().getPlayerExact(a[0]) == null) { s.sendMessage("§cИгрок не найден."); return true; }
        Store.PD giver = isOwnerOrConsole(s) ? null : pl.store.get(s.getName());
        if (giver != null) {
            boolean total = "total".equalsIgnoreCase(U.s(U.m(pl.config.get("gifts")).get("scope"), "command"));
            boolean used = total ? !giver.giftsUsed.isEmpty() : giver.giftsUsed.contains(c);
            if (used) { s.sendMessage("§cВы уже использовали " + (total ? "свой подарок привилегии." : "/" + c + ". Подарок доступен один раз за всё время.")); return true; }
        }
        Store.PD d = pl.store.get(a[0]);
        Ranks.Rank cur = pl.ranks.byId(d.rank);
        if (cur != null && cur.order >= gifted.order) { s.sendMessage("§cУ игрока уже есть эта привилегия или выше."); return true; }
        d.rank = gifted.id;
        if (giver != null) giver.giftsUsed.add(c);
        pl.store.save();
        Player on = pl.getServer().getPlayerExact(a[0]);
        if (on != null) { pl.applyPerms(on); on.sendMessage("§aВам подарили привилегию " + gifted.name + " (от " + s.getName() + ")!"); }
        s.sendMessage("§aВы подарили " + gifted.name + " игроку " + a[0]);
        pl.getLogger().info(s.getName() + " подарил " + gifted.id + " игроку " + a[0]);
        return true;
    }

    // ------------------------------------------------------------ киты

    private boolean kit(CommandSender s, String[] a) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        Map<String, Object> kits = U.m(kitsCfg.get("kits"));
        if (a.length < 1) {
            StringBuilder sb = new StringBuilder("§eВаши наборы:");
            for (String k : kits.keySet()) if (p.hasPermission("donate.kit." + k) || p.isOp()) sb.append(" ").append(k);
            p.sendMessage(sb.toString());
            return true;
        }
        String name = a[0].toLowerCase();
        if (!kits.containsKey(name)) { p.sendMessage("§cТакого набора нет."); return true; }
        if (!p.hasPermission("donate.kit." + name) && !p.isOp()) { p.sendMessage("§cНабор вам недоступен."); return true; }
        Map<String, Object> k = U.m(kits.get(name));
        long cd = U.i(k.get("cooldown"), 0) * 1000L;
        String key = p.getUniqueId() + ":kit:" + name;
        long now = System.currentTimeMillis();
        Long last = lastAct.get(key);
        if (last != null && last + cd > now && !pl.isOwner(p)) { p.sendMessage("§cНабор будет доступен через " + dur(last + cd - now)); return true; }
        for (Object o : U.l(k.get("items"))) {
            Map<String, Object> m = U.m(o);
            Map<String, Integer> en = new LinkedHashMap<>();
            for (Map.Entry<String, Object> e : U.m(m.get("enchants")).entrySet()) en.put(e.getKey(), U.i(e.getValue(), 1));
            Item it = Shop.make(U.s(m.get("material"), "air"), null, U.i(m.get("count"), 1), en);
            if (it == null) { pl.getLogger().warning("kits.yml: неизвестный предмет " + m.get("material")); continue; }
            for (Item left : p.getInventory().addItem(it)) p.getLevel().dropItem(p, left);
        }
        lastAct.put(key, now);
        p.sendMessage("§aВы получили набор " + name + ".");
        return true;
    }

    // ------------------------------------------------------------ варпы

    private boolean validName(String n) {
        return n.matches("[\\p{L}0-9_\\-]{1,24}");
    }

    private void saveWarps() {
        warpsCfg.setAll(new LinkedHashMap<String, Object>(warps));
        warpsCfg.save();
    }

    private boolean warp(CommandSender s, String[] a) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        if (a.length < 1) { p.sendMessage("§eВарпы: §f" + String.join(", ", warps.keySet())); return true; }
        Map<String, Object> w = warps.get(a[0].toLowerCase());
        if (w == null) { p.sendMessage("§cТакого варпа нет."); return true; }
        Level lv = pl.getServer().getLevelByName(U.s(w.get("level"), ""));
        if (lv == null) { p.sendMessage("§cМир варпа не загружен."); return true; }
        pl.tele.go(p, new Location(num(w.get("x")), num(w.get("y")), num(w.get("z")), num(w.get("yaw")), num(w.get("pitch")), lv), "варп " + a[0]);
        return true;
    }

    private double num(Object o) {
        return o instanceof Number ? ((Number) o).doubleValue() : 0;
    }

    private boolean setwarp(CommandSender s, String[] a) {
        if (!(s instanceof Player) || a.length < 1) { s.sendMessage("§c/setwarp <имя>"); return true; }
        Player p = (Player) s;
        String n = a[0].toLowerCase();
        if (!validName(n)) { p.sendMessage("§cИмя: буквы, цифры, _ и -, до 24 символов."); return true; }
        Map<String, Object> ex = warps.get(n);
        if (ex != null && !U.s(ex.get("owner"), "").equalsIgnoreCase(p.getName()) && !pl.isOwner(p)) {
            p.sendMessage("§cВарп с таким именем уже существует.");
            return true;
        }
        if (ex == null && !pl.isOwner(p)) {
            int mine = 0;
            for (Map<String, Object> w : warps.values()) if (U.s(w.get("owner"), "").equalsIgnoreCase(p.getName())) mine++;
            if (mine >= limit(p, "warps")) { p.sendMessage("§cЛимит варпов вашей привилегии: " + limit(p, "warps")); return true; }
        }
        Map<String, Object> w = new LinkedHashMap<>();
        w.put("owner", p.getName()); w.put("level", p.getLevel().getName());
        w.put("x", p.x); w.put("y", p.y); w.put("z", p.z); w.put("yaw", p.yaw); w.put("pitch", p.pitch);
        warps.put(n, w);
        saveWarps();
        p.sendMessage("§aВарп " + n + " создан.");
        return true;
    }

    private boolean delwarp(CommandSender s, String[] a) {
        if (a.length < 1) { s.sendMessage("§c/delwarp <имя>"); return true; }
        Map<String, Object> w = warps.get(a[0].toLowerCase());
        if (w == null) { s.sendMessage("§cТакого варпа нет."); return true; }
        if (!isOwnerOrConsole(s) && !U.s(w.get("owner"), "").equalsIgnoreCase(s.getName()) && !s.hasPermission("donate.admin")) {
            s.sendMessage("§cЭто не ваш варп.");
            return true;
        }
        warps.remove(a[0].toLowerCase());
        saveWarps();
        s.sendMessage("§aВарп удалён.");
        return true;
    }

    private boolean warpinfo(CommandSender s, String[] a) {
        if (a.length < 1) { s.sendMessage("§c/warpinfo <имя>"); return true; }
        Map<String, Object> w = warps.get(a[0].toLowerCase());
        if (w == null) { s.sendMessage("§cТакого варпа нет."); return true; }
        s.sendMessage("§eВарп " + a[0] + "\n§7Владелец: §f" + w.get("owner") + "\n§7Мир: §f" + w.get("level")
                + "\n§7Координаты: §f" + (int) num(w.get("x")) + ", " + (int) num(w.get("y")) + ", " + (int) num(w.get("z")));
        return true;
    }

    // ------------------------------------------------------------ /set и /undo

    private boolean setinfo(CommandSender s) {
        s.sendMessage("§e/set pos1 §7- первая точка (где вы стоите)\n§e/set pos2 §7- вторая точка\n"
                + "§e/set <блок> §7- заполнить область (например /set stone, /set air)\n§e/undo §7- отменить последнее /set\n"
                + "§7Лимит блоков за раз: §f" + (isOwnerOrConsole(s) ? "без лимита" : limit(s, "set_blocks")));
        return true;
    }

    private boolean set(CommandSender s, String[] a) {
        if (!(s instanceof Player) || a.length < 1) { return setinfo(s); }
        Player p = (Player) s;
        Vector3[] sl = sel.computeIfAbsent(p.getUniqueId(), k -> new Vector3[2]);
        String arg = a[0].toLowerCase();
        if (arg.equals("pos1") || arg.equals("pos2")) {
            sl[arg.equals("pos1") ? 0 : 1] = new Vector3(p.getFloorX(), p.getFloorY() - 1, p.getFloorZ());
            p.sendMessage("§a" + arg + " установлена.");
            return true;
        }
        if (sl[0] == null || sl[1] == null) { p.sendMessage("§cСначала /set pos1 и /set pos2."); return true; }
        int x1 = (int) Math.min(sl[0].x, sl[1].x), x2 = (int) Math.max(sl[0].x, sl[1].x);
        int y1 = (int) Math.min(sl[0].y, sl[1].y), y2 = (int) Math.max(sl[0].y, sl[1].y);
        int z1 = (int) Math.min(sl[0].z, sl[1].z), z2 = (int) Math.max(sl[0].z, sl[1].z);
        long vol = (long) (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1);
        long max = limit(p, "set_blocks");
        if (vol > max) { p.sendMessage("§cОбласть " + vol + " блоков, ваш лимит " + max + "."); return true; }
        Block proto;
        if (arg.equals("air")) proto = Block.get(0);
        else {
            Item it = Item.fromString(arg);
            proto = it == null || it.getId() == 0 ? null : it.getBlock();
            if (proto == null || proto.getId() == 0) { p.sendMessage("§cНеизвестный блок: " + arg); return true; }
        }
        Level lv = p.getLevel();
        List<Block> old = new ArrayList<>();
        for (int x = x1; x <= x2; x++)
            for (int y = y1; y <= y2; y++)
                for (int z = z1; z <= z2; z++) {
                    Vector3 v = new Vector3(x, y, z);
                    old.add(lv.getBlock(v));
                    lv.setBlock(v, (Block) proto.clone());
                }
        undo.put(p.getUniqueId(), old);
        p.sendMessage("§aУстановлено блоков: " + vol + ". Отмена: /undo");
        pl.getLogger().info(p.getName() + " /set " + arg + " (" + vol + " блоков)");
        return true;
    }

    private boolean undo(CommandSender s) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        List<Block> old = undo.remove(p.getUniqueId());
        if (old == null) { p.sendMessage("§cНечего отменять."); return true; }
        for (int i = old.size() - 1; i >= 0; i--) {
            Block b = old.get(i);
            b.getLevel().setBlock(new Vector3(b.x, b.y, b.z), b);
        }
        p.sendMessage("§aОтменено блоков: " + old.size());
        return true;
    }

    // ------------------------------------------------------------ наказания

    private boolean ban(CommandSender s, String[] a, String type) {
        if (a.length < 2) { s.sendMessage("§c/" + type + " <ник> <минуты|0=навсегда> [причина]"); return true; }
        String name = a[0];
        boolean perm = a[1].equals("0") || a[1].equalsIgnoreCase("perm") || a[1].equalsIgnoreCase("навсегда");
        long min = 0;
        if (perm) {
            if (!unlimited(s)) { s.sendMessage("§cНавсегда наказывать могут только Хелпер, Модератор и выше."); return true; }
        } else {
            min = parseMinutes(s, a[1], limit(s, type + "_max"));
            if (min < 0) return true;
        }
        String span = perm ? "навсегда" : min + " мин";
        if (!canTouch(s, name) || !delayOk(s, type)) return true;
        if (punish.active(type, name) != null) { s.sendMessage("§cУ игрока уже есть активное наказание."); return true; }
        String reason = reasonFrom(a, 2);
        Punish.Rec r = punish.add(type, name, s.getName(), reason, perm ? 0 : System.currentTimeMillis() + min * 60000L);
        Player on = pl.getServer().getPlayerExact(name);
        if (type.equals("ban")) {
            if (on != null) on.kick(PlayerKickEvent.Reason.UNKNOWN, "§cВы забанены до " + date(r.until) + "\n§7Причина: " + reason, false);
            s.sendMessage("§aИгрок " + name + " забанен: " + span + ".");
        } else {
            if (on != null) on.sendMessage("§cВы замучены: " + span + ". Причина: " + reason);
            s.sendMessage("§aИгрок " + name + " замучен: " + span + ".");
        }
        pl.getLogger().info(s.getName() + " " + type + " " + name + " " + span + ": " + reason);
        return true;
    }

    private boolean unban(CommandSender s, String[] a, String type) {
        if (a.length < 1) { s.sendMessage("§c/un" + type + " <ник>"); return true; }
        Punish.Rec r = punish.active(type, a[0]);
        if (r == null) { s.sendMessage("§cАктивного наказания нет."); return true; }
        if (!isOwnerOrConsole(s) && !r.by.equalsIgnoreCase(s.getName()) && !s.hasPermission("donate.admin")
                && orderOf(r.by) >= orderOf(s.getName())) {
            s.sendMessage("§cНаказание выдал игрок с более высокой привилегией.");
            return true;
        }
        punish.lift(type, a[0]);
        Player on = pl.getServer().getPlayerExact(a[0]);
        if (on != null && type.equals("mute")) on.sendMessage("§aМут снят.");
        s.sendMessage("§aНаказание снято с " + a[0]);
        return true;
    }

    private boolean kick(CommandSender s, String[] a) {
        if (a.length < 1) { s.sendMessage("§c/kick <ник> [причина]"); return true; }
        Player t = online(s, a[0]);
        if (t == null || !canTouch(s, t.getName()) || !delayOk(s, "kick")) return true;
        String reason = reasonFrom(a, 1);
        punish.add("kick", t.getName(), s.getName(), reason, 0);
        t.kick(PlayerKickEvent.Reason.UNKNOWN, "§cВас исключили\n§7Причина: " + reason, false);
        s.sendMessage("§aИгрок исключён.");
        return true;
    }

    private boolean list(CommandSender s, String type, boolean lifted) {
        List<Punish.Rec> l = lifted ? punish.liftedList(type) : punish.activeList(type);
        if (l.isEmpty()) { s.sendMessage("§7Список пуст."); return true; }
        StringBuilder sb = new StringBuilder("§e" + (lifted ? "Снятые " : "Активные ") + (type.equals("ban") ? "баны" : "муты") + ":");
        int from = Math.max(0, l.size() - 20);
        for (int i = from; i < l.size(); i++) {
            Punish.Rec r = l.get(i);
            sb.append("\n§7").append(r.target).append(" §f(до ").append(date(r.until)).append(", ").append(r.by).append("): ").append(r.reason);
        }
        s.sendMessage(sb.toString());
        return true;
    }

    private boolean kicklist(CommandSender s) {
        List<Punish.Rec> l = punish.all("kick");
        if (l.isEmpty()) { s.sendMessage("§7Список пуст."); return true; }
        StringBuilder sb = new StringBuilder("§eПоследние кики:");
        for (int i = Math.max(0, l.size() - 20); i < l.size(); i++) {
            Punish.Rec r = l.get(i);
            sb.append("\n§7").append(r.target).append(" §f(").append(date(r.created)).append(", ").append(r.by).append("): ").append(r.reason);
        }
        s.sendMessage(sb.toString());
        return true;
    }

    private boolean see(CommandSender s, String[] a, String type) {
        if (a.length < 1) { s.sendMessage("§c/" + type + "see <ник>"); return true; }
        List<Punish.Rec> l = punish.byTarget(type, a[0]);
        if (l.isEmpty()) { s.sendMessage("§7У игрока нет записей."); return true; }
        StringBuilder sb = new StringBuilder("§e" + a[0] + ":");
        for (Punish.Rec r : l)
            sb.append("\n§7").append(date(r.created)).append(" §f").append(r.by).append(", до ").append(date(r.until))
                    .append(r.lifted ? " (снят)" : "").append(": ").append(r.reason);
        s.sendMessage(sb.toString());
        return true;
    }

    // ============================================================ события

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player && god.contains(e.getEntity().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onFood(PlayerFoodLevelChangeEvent e) {
        if (noHunger.contains(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onPickup(InventoryPickupItemEvent e) {
        if (e.getInventory().getHolder() instanceof Player
                && noPickup.contains(((Player) e.getInventory().getHolder()).getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onTeleport(PlayerTeleportEvent e) {
        if (e.isCancelled()) return;
        Player p = e.getPlayer();
        back.put(p.getUniqueId(), e.getFrom());
        for (UUID id : tpInfo) {
            Optional<Player> o = pl.getServer().getPlayer(id);
            if (o.isPresent() && o.get() != p)
                o.get().sendMessage("§7[TP] " + p.getName() + ": " + e.getFrom().getFloorX() + "," + e.getFrom().getFloorY() + ","
                        + e.getFrom().getFloorZ() + " → " + e.getTo().getFloorX() + "," + e.getTo().getFloorY() + "," + e.getTo().getFloorZ());
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        back.put(p.getUniqueId(), p.getLocation());
        pl.store.get(p.getName()).deaths++;
        EntityDamageEvent cause = p.getLastDamageCause();
        if (cause instanceof EntityDamageByEntityEvent && ((EntityDamageByEntityEvent) cause).getDamager() instanceof Player)
            pl.store.get(((Player) ((EntityDamageByEntityEvent) cause).getDamager()).getName()).kills++;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        pl.store.get(e.getPlayer().getName()).broken++;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        pl.store.get(e.getPlayer().getName()).placed++;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        joined.put(p.getUniqueId(), System.currentTimeMillis());
        if (!p.hasPermission("donate.cmd.vanish")) {
            for (UUID id : vanished) {
                Optional<Player> v = pl.getServer().getPlayer(id);
                v.ifPresent(p::hidePlayer);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        Long j = joined.remove(id);
        if (j != null) pl.store.get(e.getPlayer().getName()).playMs += System.currentTimeMillis() - j;
        vanished.remove(id); god.remove(id); noHunger.remove(id); noPickup.remove(id);
        tpOff.remove(id); tpInfo.remove(id); skinRestore.remove(id); back.remove(id);
        sel.remove(id); undo.remove(id);
    }
}
