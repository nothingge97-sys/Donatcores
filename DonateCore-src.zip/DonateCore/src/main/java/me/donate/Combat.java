package me.donate;

import cn.nukkit.Player;
import cn.nukkit.command.CommandSender;
import cn.nukkit.math.Vector3;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.entity.EntityDamageByEntityEvent;
import cn.nukkit.event.player.PlayerCommandPreprocessEvent;
import cn.nukkit.event.player.PlayerDeathEvent;
import cn.nukkit.event.player.PlayerJoinEvent;
import cn.nukkit.event.player.PlayerKickEvent;
import cn.nukkit.event.player.PlayerQuitEvent;
import cn.nukkit.item.Item;
import cn.nukkit.level.Location;
import cn.nukkit.utils.Config;

import java.io.File;
import java.util.*;

/**
 * Антирелог: после PvP оба игрока "в бою" N секунд.
 * Выход из игры во время боя = смерть (вещи выпадают на землю), в бою нельзя летать и вводить часть команд.
 */
public class Combat implements Listener {

    private final DonatePlugin pl;
    private final boolean enabled, disableFly, broadcast, punish;
    private final int seconds;
    private final Set<String> blocked = new HashSet<>();
    private final boolean arenaOnly;

    // --- PvP арены (arenas.yml): куб по X/Y/Z в одном мире ---
    private static class Arena {
        String name, level;
        int x1, y1, z1, x2, y2, z2;
    }
    private final Config arenaCfg;
    private final Map<String, Arena> arenas = new LinkedHashMap<>();
    private final Map<UUID, int[]> sel = new HashMap<>();      // x1,y1,z1,x2,y2,z2,set1,set2
    private final Map<UUID, String> selLevel = new HashMap<>();

    private final Map<UUID, Long> until = new HashMap<>();
    private final Map<UUID, String> opponent = new HashMap<>();

    public Combat(DonatePlugin pl, Config cfg) {
        this.pl = pl;
        Map<String, Object> c = U.m(cfg.get("combat"));
        enabled = U.b(c.get("enabled"), true);
        seconds = Math.max(1, U.i(c.get("seconds"), 15));
        disableFly = U.b(c.get("disable_fly"), true);
        broadcast = U.b(c.get("broadcast"), true);
        punish = !"warn".equalsIgnoreCase(U.s(c.get("on_logout"), "kill"));
        arenaOnly = U.b(c.get("arena_only"), true);
        arenaCfg = new Config(new File(pl.getDataFolder(), "arenas.yml"), Config.YAML);
        for (Map.Entry<String, Object> e : arenaCfg.getAll().entrySet()) {
            Map<String, Object> m = U.m(e.getValue());
            Arena a = new Arena();
            a.name = e.getKey();
            a.level = U.s(m.get("level"), "");
            a.x1 = U.i(m.get("x1"), 0); a.y1 = U.i(m.get("y1"), 0); a.z1 = U.i(m.get("z1"), 0);
            a.x2 = U.i(m.get("x2"), 0); a.y2 = U.i(m.get("y2"), 0); a.z2 = U.i(m.get("z2"), 0);
            arenas.put(a.name, a);
        }
        for (Object o : U.l(c.get("block_commands"))) blocked.add(String.valueOf(o).toLowerCase(Locale.ROOT));
        if (enabled) {
            pl.getServer().getScheduler().scheduleRepeatingTask(pl, this::tick, 20);
        }
    }

    public boolean inCombat(Player p) {
        Long t = until.get(p.getUniqueId());
        return t != null && t > System.currentTimeMillis();
    }

    private boolean exempt(Player p) {
        return p.hasPermission("donate.combat.bypass") || pl.isOwner(p);
    }

    private void tag(Player p, Player other) {
        if (exempt(p)) return;
        boolean first = !inCombat(p);
        until.put(p.getUniqueId(), System.currentTimeMillis() + seconds * 1000L);
        opponent.put(p.getUniqueId(), other.getName());
        if (first) p.sendMessage("§c§lВы в бою! §fНе выходите из игры " + seconds + " сек.");
        if (disableFly && p.getGamemode() != 1 && p.getGamemode() != 3 && p.getAllowFlight()) {
            p.setAllowFlight(false);
            p.sendMessage("§cПолёт отключён на время боя.");
        }
    }

    private void untag(UUID id) {
        until.remove(id);
        opponent.remove(id);
    }

    private void tick() {
        long now = System.currentTimeMillis();
        for (Iterator<Map.Entry<UUID, Long>> it = until.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Long> e = it.next();
            Optional<Player> p = pl.getServer().getPlayer(e.getKey());
            if (!p.isPresent()) { it.remove(); opponent.remove(e.getKey()); continue; }
            if (e.getValue() <= now) {
                it.remove();
                opponent.remove(e.getKey());
                p.get().sendMessage("§aБой окончен, теперь можно выходить.");
            } else {
                p.get().sendTip("§cВ бою: §f" + ((e.getValue() - now + 999) / 1000) + " сек");
            }
        }
    }

    // ------------------------------------------------------------ арены

    public boolean inArena(Player p) {
        String lv = p.getLevel().getName();
        int x = p.getFloorX(), y = p.getFloorY(), z = p.getFloorZ();
        for (Arena a : arenas.values())
            if (a.level.equals(lv) && x >= a.x1 && x <= a.x2 && y >= a.y1 && y <= a.y2 && z >= a.z1 && z <= a.z2) return true;
        return false;
    }

    private void saveArenas() {
        LinkedHashMap<String, Object> out = new LinkedHashMap<>();
        for (Arena a : arenas.values()) {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("level", a.level);
            m.put("x1", a.x1); m.put("y1", a.y1); m.put("z1", a.z1);
            m.put("x2", a.x2); m.put("y2", a.y2); m.put("z2", a.z2);
            out.put(a.name, m);
        }
        arenaCfg.setAll(out);
        arenaCfg.save();
    }

    /** /arena pos1|pos2|set <имя>|remove <имя>|list|here (для админов). */
    public boolean arenaCommand(CommandSender s, String[] a) {
        if (!s.hasPermission("donate.admin")) { s.sendMessage("§cНет прав."); return true; }
        String sub = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "help";
        if (sub.equals("list")) {
            s.sendMessage(arenas.isEmpty() ? "§7Арен нет. Создайте: /arena pos1, /arena pos2, /arena set <имя>"
                    : "§eПвП арены: §f" + String.join(", ", arenas.keySet()));
            return true;
        }
        if (sub.equals("remove")) {
            if (a.length < 2 || arenas.remove(a[1].toLowerCase(Locale.ROOT)) == null) { s.sendMessage("§cАрена не найдена. /arena remove <имя>"); return true; }
            saveArenas();
            s.sendMessage("§aАрена удалена.");
            return true;
        }
        if (!(s instanceof Player)) { s.sendMessage("Только в игре."); return true; }
        Player p = (Player) s;
        int[] st = sel.computeIfAbsent(p.getUniqueId(), k -> new int[8]);
        switch (sub) {
            case "pos1": case "pos2": {
                boolean first = sub.equals("pos1");
                String lv = selLevel.get(p.getUniqueId());
                if (lv != null && !lv.equals(p.getLevel().getName())) { st[6] = 0; st[7] = 0; }
                selLevel.put(p.getUniqueId(), p.getLevel().getName());
                int o = first ? 0 : 3;
                st[o] = p.getFloorX(); st[o + 1] = p.getFloorY(); st[o + 2] = p.getFloorZ();
                st[first ? 6 : 7] = 1;
                p.sendMessage("§aТочка " + (first ? "1" : "2") + ": " + p.getFloorX() + ", " + p.getFloorY() + ", " + p.getFloorZ()
                        + "\n§7Подсказка: pos1 - у земли в одном углу, pos2 - в противоположном углу на высоте потолка арены.");
                return true;
            }
            case "set": {
                if (a.length < 2) { p.sendMessage("§c/arena set <имя>"); return true; }
                String name = a[1].toLowerCase(Locale.ROOT);
                if (!name.matches("[\\p{L}0-9_\\-]{1,24}")) { p.sendMessage("§cИмя: буквы, цифры, _ и -."); return true; }
                if (st[6] == 0 || st[7] == 0 || !p.getLevel().getName().equals(selLevel.get(p.getUniqueId()))) {
                    p.sendMessage("§cСначала /arena pos1 и /arena pos2 в этом мире.");
                    return true;
                }
                Arena ar = new Arena();
                ar.name = name; ar.level = p.getLevel().getName();
                ar.x1 = Math.min(st[0], st[3]); ar.x2 = Math.max(st[0], st[3]);
                ar.y1 = Math.min(st[1], st[4]); ar.y2 = Math.max(st[1], st[4]);
                ar.z1 = Math.min(st[2], st[5]); ar.z2 = Math.max(st[2], st[5]);
                arenas.put(name, ar);
                saveArenas();
                p.sendMessage("§aПвП арена " + name + " создана: " + (ar.x2 - ar.x1 + 1) + "x" + (ar.y2 - ar.y1 + 1) + "x" + (ar.z2 - ar.z1 + 1) + " блоков.");
                return true;
            }
            case "here":
                p.sendMessage(inArena(p) ? "§aВы на PvP арене." : "§7Вы вне PvP арены.");
                return true;
            default:
                p.sendMessage("§e/arena pos1, /arena pos2 §7- углы арены\n§e/arena set <имя> §7- создать\n§e/arena remove <имя>, /arena list, /arena here");
                return true;
        }
    }

    // ------------------------------------------------------------ события

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!enabled) return;
        if (!(e.getEntity() instanceof Player) || !(e.getDamager() instanceof Player)) return;
        Player victim = (Player) e.getEntity(), attacker = (Player) e.getDamager();
        if (victim == attacker || !pl.isAuthed(victim) || !pl.isAuthed(attacker)) return;
        // Только на PvP арене: оба игрока должны быть внутри арены в момент удара.
        if (arenaOnly && (!inArena(victim) || !inArena(attacker))) return;
        // Только настоящий PvP: удар должен нанести урон, и никто из двоих не в креативе/наблюдателе.
        if (e.getFinalDamage() <= 0) return;
        if (attacker.getGamemode() == 1 || attacker.getGamemode() == 3) return;
        if (victim.getGamemode() == 1 || victim.getGamemode() == 3) return;
        tag(victim, attacker);
        tag(attacker, victim);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!enabled || !inCombat(e.getPlayer())) return;
        String m = e.getMessage();
        if (!m.startsWith("/")) return;
        String cmd = m.substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        if (cmd.contains(":")) cmd = cmd.substring(cmd.indexOf(':') + 1);
        if (blocked.contains(cmd)) {
            e.setCancelled(true);
            e.getPlayer().sendMessage("§cВо время боя эта команда недоступна.");
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        untag(e.getEntity().getUniqueId());
    }

    /** Кикнули администраторы - это не побег из боя. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onKick(PlayerKickEvent e) {
        if (!e.isCancelled()) untag(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (!enabled || !inCombat(p)) { untag(p.getUniqueId()); return; }
        String enemy = opponent.get(p.getUniqueId());
        untag(p.getUniqueId());
        if (!pl.getServer().isRunning()) return; // остановка сервера - не наказываем

        if (broadcast) pl.getServer().broadcastMessage("§c§l" + p.getName() + " §eвышел из игры во время боя и был наказан!");
        if (!punish) return;

        Store.PD d = pl.store.get(p.getName());
        d.deaths++;
        d.combatPenalty = true;
        if (enemy != null && pl.store.exists(enemy)) pl.store.get(enemy).kills++;
        for (Item it : new ArrayList<>(p.getInventory().getContents().values()))
            if (it != null && it.getId() != 0) p.getLevel().dropItem(p, it);
        for (Item it : p.getInventory().getArmorContents())
            if (it != null && it.getId() != 0) p.getLevel().dropItem(p, it);
        p.getInventory().clearAll();
        pl.store.save();
        pl.getLogger().info("Антирелог: " + p.getName() + " вышел в бою (противник: " + enemy + ")");
    }

    /** Вернулся после выхода в бою: инвентарь уже выпал, возвращаем на спавн с полным здоровьем. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Store.PD d = pl.store.get(p.getName());
        if (!d.combatPenalty) return;
        d.combatPenalty = false;
        p.getInventory().clearAll();
        p.setHealth(p.getMaxHealth());
        p.teleport(Location.fromObject(p.getLevel().getSafeSpawn(), p.getLevel()));
        p.sendMessage("§cВы вышли во время боя: вещи остались на месте выхода.");
        pl.store.save();
    }
}
