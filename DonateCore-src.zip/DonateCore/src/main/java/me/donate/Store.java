package me.donate;

import cn.nukkit.utils.Config;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.File;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;

/** Данные игроков (players.yml): койны, привилегия, префиксы, пароль (только хэш). */
public class Store {

    public static class PD {
        public String pass = "";
        public long coins = 0;
        public String rank = "";
        public List<String> cosmetics = new ArrayList<>();
        public String activeCosmetic = "";
        public String activePref = ""; // "" = по умолчанию (свой), "none" = скрыть, иначе id привилегии
        public long kills, deaths, broken, placed, playMs;
        public boolean combatPenalty; // вышел в бою, наказание применить при входе
        public long money = 0; // игровые монеты (не койны)
        public Map<String, Integer> keys = new LinkedHashMap<>(); // ключи от кейсов
        public List<String> giftsUsed = new ArrayList<>(); // команды /give*, которые игрок уже использовал
    }

    private final Config cfg;
    private final Map<String, PD> map = new HashMap<>();

    public Store(File file) {
        cfg = new Config(file, Config.YAML);
        for (String key : cfg.getAll().keySet()) {
            Map<String, Object> m = U.m(cfg.get(key));
            PD d = new PD();
            d.pass = U.s(m.get("pass"), "");
            d.coins = m.get("coins") instanceof Number ? ((Number) m.get("coins")).longValue() : 0;
            d.rank = U.s(m.get("rank"), "");
            for (Object o : U.l(m.get("cosmetics"))) d.cosmetics.add(String.valueOf(o));
            d.activeCosmetic = U.s(m.get("activeCosmetic"), "");
            d.activePref = U.s(m.get("activePref"), "");
            d.kills = L(m.get("kills")); d.deaths = L(m.get("deaths")); d.broken = L(m.get("broken"));
            d.placed = L(m.get("placed")); d.playMs = L(m.get("playMs"));
            d.money = L(m.get("money"));
            d.combatPenalty = U.b(m.get("combatPenalty"), false);
            for (Map.Entry<String, Object> ke : U.m(m.get("keys")).entrySet()) d.keys.put(ke.getKey(), U.i(ke.getValue(), 0));
            for (Object o : U.l(m.get("giftsUsed"))) d.giftsUsed.add(String.valueOf(o));
            map.put(key, d);
        }
    }

    private static long L(Object o) {
        return o instanceof Number ? ((Number) o).longValue() : 0;
    }

    public Map<String, PD> all() {
        return map;
    }

    private static String key(String name) {
        return name.toLowerCase(Locale.ROOT).replace('.', '_');
    }

    public PD get(String name) {
        return map.computeIfAbsent(key(name), k -> new PD());
    }

    public boolean exists(String name) {
        return map.containsKey(key(name));
    }

    public synchronized void save() {
        LinkedHashMap<String, Object> out = new LinkedHashMap<>();
        for (Map.Entry<String, PD> e : map.entrySet()) {
            PD d = e.getValue();
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("pass", d.pass);
            m.put("coins", d.coins);
            m.put("rank", d.rank);
            m.put("cosmetics", new ArrayList<>(d.cosmetics));
            m.put("activeCosmetic", d.activeCosmetic);
            m.put("activePref", d.activePref);
            m.put("kills", d.kills); m.put("deaths", d.deaths); m.put("broken", d.broken);
            m.put("placed", d.placed); m.put("playMs", d.playMs);
            m.put("giftsUsed", new ArrayList<>(d.giftsUsed));
            m.put("money", d.money);
            m.put("combatPenalty", d.combatPenalty);
            m.put("keys", new LinkedHashMap<>(d.keys));
            out.put(e.getKey(), m);
        }
        cfg.setAll(out);
        cfg.save();
    }

    // ---------- пароли: PBKDF2, хранится только хэш ----------
    private static final int ITER = 60000;

    public static String hash(String pass) {
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            byte[] h = pbkdf2(pass, salt, ITER);
            return "pbkdf2$" + ITER + "$" + hex(salt) + "$" + hex(h);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean check(String pass, String stored) {
        try {
            String[] p = stored.split("\\$");
            if (p.length != 4 || !p[0].equals("pbkdf2")) return false;
            byte[] h = pbkdf2(pass, unhex(p[2]), Integer.parseInt(p[1]));
            return MessageDigest.isEqual(h, unhex(p[3]));
        } catch (Exception e) {
            return false;
        }
    }

    private static byte[] pbkdf2(String pass, byte[] salt, int iter) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pass.toCharArray(), salt, iter, 256);
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    private static byte[] unhex(String s) {
        byte[] r = new byte[s.length() / 2];
        for (int i = 0; i < r.length; i++) r[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        return r;
    }
}
