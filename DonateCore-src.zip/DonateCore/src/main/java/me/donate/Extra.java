package me.donate;

import cn.nukkit.Player;
import cn.nukkit.block.Block;
import cn.nukkit.command.CommandSender;
import cn.nukkit.entity.Entity;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.entity.EntityDamageByEntityEvent;
import cn.nukkit.event.entity.EntityShootBowEvent;
import cn.nukkit.event.entity.ProjectileHitEvent;
import cn.nukkit.event.inventory.InventoryCloseEvent;
import cn.nukkit.event.player.PlayerMoveEvent;
import cn.nukkit.event.player.PlayerQuitEvent;
import cn.nukkit.inventory.Inventory;
import cn.nukkit.item.Item;
import cn.nukkit.level.Level;
import cn.nukkit.math.Vector3;
import cn.nukkit.nbt.tag.CompoundTag;
import cn.nukkit.potion.Effect;
import cn.nukkit.utils.Config;

import java.util.*;

/**
 * Команды, которым нужны особые API: /stick /tpbow /sleep /craft /enderchest /enderchestsee /flyspeed /ac /console.
 * Всё, в чём я не уверен для твоей версии ядра, вызывается через reflection и при ошибке даёт понятное сообщение.
 */
public class Extra implements Listener {

    private static final String STICK = "donate_stick";

    private final DonatePlugin pl;
    private final Set<UUID> tpbow = new HashSet<>();
    private final Map<Long, UUID> arrows = new HashMap<>();
    private final Map<UUID, Vector3> craftBlocks = new HashMap<>();

    // --- античит ---
    private boolean acOn;
    private double acMaxSpeed;
    private int acFlyTicks, acAlertEvery;
    private final Map<String, Integer> suspects = new LinkedHashMap<>();
    private final Map<UUID, int[]> acState = new HashMap<>(); // [fastMoves, airTicks]
    private final Set<UUID> acMute = new HashSet<>();

    // --- /console ---
    private final Set<String> consoleAllowed = new HashSet<>();

    public Extra(DonatePlugin pl, Config cfg) {
        this.pl = pl;
        Map<String, Object> ac = U.m(cfg.get("anticheat"));
        acOn = U.b(ac.get("enabled"), true);
        acMaxSpeed = ac.get("max_speed") instanceof Number ? ((Number) ac.get("max_speed")).doubleValue() : 0.9;
        acFlyTicks = U.i(ac.get("fly_ticks"), 60);
        acAlertEvery = Math.max(1, U.i(ac.get("alert_every"), 5));
        for (Object o : U.l(U.m(cfg.get("console")).get("allowed"))) consoleAllowed.add(String.valueOf(o).toLowerCase(Locale.ROOT));
    }

    public boolean handle(CommandSender s, String c, String[] a) {
        switch (c) {
            case "stick": return stick(s);
            case "tpbow": return tpbowToggle(s);
            case "sleep": return sleep(s);
            case "craft": return craft(s);
            case "enderchest": return ender(s, null);
            case "enderchestsee": return ender(s, a);
            case "flyspeed": return flyspeed(s, a);
            case "ac": return ac(s, a);
            case "console": return console(s, a);
            default: return false;
        }
    }

    private boolean player(CommandSender s) {
        if (s instanceof Player) return true;
        s.sendMessage("Эту команду можно выполнить только в игре.");
        return false;
    }

    // ================================================================ /stick

    private boolean stick(CommandSender s) {
        if (!player(s)) return true;
        Player p = (Player) s;
        Item it = Item.fromString("stick");
        if (it == null || it.getId() == 0) { p.sendMessage("§cПалка недоступна."); return true; }
        it.setCustomName("§d§lПалочка управления");
        it.setLore("§7Ударьте игрока - откроется меню управления");
        CompoundTag tag = it.hasCompoundTag() ? it.getNamedTag() : new CompoundTag();
        tag.putByte(STICK, 1);
        it.setNamedTag(tag);
        for (Item left : p.getInventory().addItem(it)) p.getLevel().dropItem(p, left);
        p.sendMessage("§aВы получили палочку управления.");
        return true;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onStickHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player) || !(e.getEntity() instanceof Player)) return;
        Player d = (Player) e.getDamager();
        Item hand = d.getInventory().getItemInHand();
        if (hand == null || !hand.hasCompoundTag() || !hand.getNamedTag().contains(STICK)) return;
        e.setCancelled(true);
        if (!pl.isAuthed(d) || !d.hasPermission("donate.cmd.stick")) return;
        pl.cmds.handle(d, "player", new String[]{((Player) e.getEntity()).getName()});
    }

    // ================================================================ /tpbow

    private boolean tpbowToggle(CommandSender s) {
        if (!player(s)) return true;
        Player p = (Player) s;
        boolean on = tpbow.add(p.getUniqueId());
        if (!on) tpbow.remove(p.getUniqueId());
        p.sendMessage(on ? "§aЛук-телепортер включён: телепорт туда, куда попадёт стрела." : "§cЛук-телепортер выключен.");
        return true;
    }

    @EventHandler
    public void onShoot(EntityShootBowEvent e) {
        if (!(e.getEntity() instanceof Player)) return;
        Player p = (Player) e.getEntity();
        if (!tpbow.contains(p.getUniqueId()) || e.getProjectile() == null) return;
        if (arrows.size() > 300) arrows.clear();
        arrows.put(e.getProjectile().getId(), p.getUniqueId());
    }

    @EventHandler
    public void onArrowHit(ProjectileHitEvent e) {
        Entity arrow = e.getEntity();
        UUID id = arrows.remove(arrow.getId());
        if (id == null) return;
        Optional<Player> shooter = pl.getServer().getPlayer(id);
        if (!shooter.isPresent()) return;
        shooter.get().teleport(new Vector3(arrow.x, arrow.y + 1, arrow.z));
        arrow.close();
    }

    // ================================================================ /sleep

    private boolean sleep(CommandSender s) {
        if (!player(s)) return true;
        Player p = (Player) s;
        Level lv = p.getLevel();
        int t = lv.getTime() % 24000;
        if (t < 12500) { p.sendMessage("§cСейчас день, спать не хочется."); return true; }
        lv.setTime(0);
        pl.getServer().broadcastMessage("§e" + p.getName() + " лёг спать. Наступило утро.");
        return true;
    }

    // ================================================================ /enderchest

    private boolean ender(CommandSender s, String[] other) {
        if (!player(s)) return true;
        Player viewer = (Player) s;
        Player owner = viewer;
        if (other != null) {
            if (other.length < 1) { s.sendMessage("§c/enderchestsee <игрок>"); return true; }
            owner = pl.getServer().getPlayer(other[0]);
            if (owner == null) { s.sendMessage("§cИгрок не найден (должен быть онлайн)."); return true; }
        }
        try {
            Object inv = owner.getClass().getMethod("getEnderChestInventory").invoke(owner);
            viewer.addWindow((Inventory) inv);
        } catch (Throwable t) {
            viewer.sendMessage("§cЭндер-сундук не поддерживается этой версией ядра.");
            pl.getLogger().warning("enderchest: " + t);
        }
        return true;
    }

    // ================================================================ /flyspeed

    private boolean flyspeed(CommandSender s, String[] a) {
        if (!player(s)) return true;
        Player p = (Player) s;
        if (a.length < 1) { p.sendMessage("§c/flyspeed <1-5> (1 = обычная)"); return true; }
        double v;
        try { v = Double.parseDouble(a[0]); } catch (NumberFormatException e) { p.sendMessage("§cЧисло неверное."); return true; }
        if (v < 1 || v > 5) { p.sendMessage("§cДопустимо от 1 до 5."); return true; }
        try {
            p.getClass().getMethod("setFlySpeed", float.class).invoke(p, (float) (0.05 * v));
            p.sendMessage("§aСкорость полёта: x" + v);
        } catch (Throwable t) {
            p.sendMessage("§cСкорость полёта не поддерживается этой версией ядра.");
        }
        return true;
    }

    // ================================================================ /console (только разрешённые команды)

    private boolean console(CommandSender s, String[] a) {
        if (a.length < 1) {
            s.sendMessage("§eРазрешённые команды: §f" + (consoleAllowed.isEmpty() ? "нет (config.yml -> console.allowed)" : String.join(", ", consoleAllowed)));
            return true;
        }
        String line = String.join(" ", a).replace("\n", " ").replace("\r", " ").trim();
        if (line.startsWith("/")) line = line.substring(1);
        String first = line.split(" ")[0].toLowerCase(Locale.ROOT);
        if (!consoleAllowed.contains(first) && !(s instanceof Player && pl.isOwner((Player) s))) {
            s.sendMessage("§cЭта команда не разрешена в режиме консоли.");
            return true;
        }
        pl.getLogger().info("[console] " + s.getName() + ": " + line);
        pl.getServer().dispatchCommand(pl.getServer().getConsoleSender(), line);
        return true;
    }

    // ================================================================ /craft (экспериментально)

    private boolean craft(CommandSender s) {
        if (!player(s)) return true;
        Player p = (Player) s;
        removeCraft(p.getUniqueId());
        Level lv = p.getLevel();
        Vector3 pos = new Vector3(p.getFloorX(), p.getFloorY() + 2, p.getFloorZ());
        if (lv.getBlock(pos).getId() != 0) { p.sendMessage("§cНад головой должно быть свободное место (2 блока)."); return true; }
        try {
            lv.setBlock(pos, Block.get(58)); // верстак
            Block table = lv.getBlock(pos);
            table.getClass().getMethod("onActivate", Item.class, Player.class).invoke(table, Item.get(0), p);
            craftBlocks.put(p.getUniqueId(), pos);
            final UUID id = p.getUniqueId();
            pl.getServer().getScheduler().scheduleDelayedTask(pl, () -> removeCraft(id), 20 * 60 * 3);
        } catch (Throwable t) {
            lv.setBlock(pos, Block.get(0));
            p.sendMessage("§cВиртуальный верстак не поддерживается этой версией ядра.");
            pl.getLogger().warning("craft: " + t);
        }
        return true;
    }

    private void removeCraft(UUID id) {
        Vector3 pos = craftBlocks.remove(id);
        if (pos == null) return;
        Optional<Player> p = pl.getServer().getPlayer(id);
        Level lv = p.isPresent() ? p.get().getLevel() : pl.getServer().getDefaultLevel();
        if (lv != null && lv.getBlock(pos).getId() == 58) lv.setBlock(pos, Block.get(0));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        removeCraft(e.getPlayer().getUniqueId());
    }

    // ================================================================ античит (базовый)

    private boolean ac(CommandSender s, String[] a) {
        String sub = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "list";
        switch (sub) {
            case "on": case "off":
                if (!s.hasPermission("donate.admin")) { s.sendMessage("§cНет прав."); return true; }
                acOn = sub.equals("on");
                s.sendMessage("§eАнтичит: " + (acOn ? "§aвключён" : "§cвыключен"));
                return true;
            case "alerts":
                if (!player(s)) return true;
                UUID id = ((Player) s).getUniqueId();
                boolean muted = acMute.add(id);
                if (!muted) acMute.remove(id);
                s.sendMessage("§eУведомления античита: " + (muted ? "§cвыключены" : "§aвключены"));
                return true;
            case "clear":
                if (a.length > 1) suspects.remove(a[1]); else suspects.clear();
                s.sendMessage("§aСписок очищен.");
                return true;
            default:
                if (suspects.isEmpty()) { s.sendMessage("§7Подозреваемых нет. Античит: " + (acOn ? "§aвкл" : "§cвыкл")); return true; }
                StringBuilder sb = new StringBuilder("§eПодозреваемые (античит " + (acOn ? "вкл" : "выкл") + "):");
                suspects.entrySet().stream().sorted((x, y) -> y.getValue() - x.getValue()).limit(15)
                        .forEach(en -> sb.append("\n§7").append(en.getKey()).append(": §f").append(en.getValue()));
                s.sendMessage(sb.toString());
                s.sendMessage("§7/ac clear [ник], /ac alerts, /ac on|off");
                return true;
        }
    }

    private void flag(Player p, String what) {
        int n = suspects.merge(p.getName(), 1, Integer::sum);
        if (n % acAlertEvery != 0) return;
        for (Player o : pl.getServer().getOnlinePlayers().values())
            if (o.hasPermission("donate.cmd.ac") && !acMute.contains(o.getUniqueId()))
                o.sendMessage("§c[AC] §f" + p.getName() + " §7- " + what + " (" + n + ")");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!acOn) return;
        Player p = e.getPlayer();
        if (!pl.isAuthed(p) || p.isOp() || p.hasPermission("donate.ac.bypass")) return;
        int gm = p.getGamemode();
        int[] st = acState.computeIfAbsent(p.getUniqueId(), k -> new int[2]);
        if (gm == 1 || gm == 3 || p.getAllowFlight() || p.isGliding()) { st[0] = 0; st[1] = 0; return; }

        // скорость по горизонтали
        double dx = e.getTo().x - e.getFrom().x, dz = e.getTo().z - e.getFrom().z;
        double d = Math.sqrt(dx * dx + dz * dz);
        double allowed = acMaxSpeed;
        if (p.hasEffect(Effect.SPEED)) allowed *= 1 + 0.4 * (p.getEffect(Effect.SPEED).getAmplifier() + 1);
        if (d > allowed) {
            if (++st[0] >= 3) { flag(p, "скорость " + String.format("%.2f", d)); st[0] = 0; }
        } else if (st[0] > 0) st[0]--;

        // полёт: долго в воздухе без падения
        int feet = p.getLevel().getBlock(new Vector3(p.getFloorX(), p.getFloorY(), p.getFloorZ())).getId();
        boolean climbing = feet == 65 || feet == 106 || feet == 8 || feet == 9; // лестница, лианы, вода
        if (!p.isOnGround() && !climbing && !p.hasEffect(Effect.LEVITATION) && e.getTo().y >= e.getFrom().y - 0.01) {
            if (++st[1] > acFlyTicks) { flag(p, "полёт"); st[1] = 0; }
        } else st[1] = 0;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        tpbow.remove(id);
        acState.remove(id);
        acMute.remove(id);
        removeCraft(id);
    }
}
