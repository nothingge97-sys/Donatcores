package me.donate;

import cn.nukkit.utils.Config;

import java.io.File;
import java.util.*;

/** Баны, муты, кики (punish.yml). until = 0 означает навсегда. */
public class Punish {

    public static class Rec {
        public int id;
        public String type, target, by, reason;
        public long created, until;
        public boolean active = true, lifted;
    }

    private final Config cfg;
    private final List<Rec> recs = new ArrayList<>();
    private int next = 1;

    public Punish(File file) {
        cfg = new Config(file, Config.YAML);
        for (Object o : U.l(cfg.get("records"))) {
            Map<String, Object> m = U.m(o);
            Rec r = new Rec();
            r.id = U.i(m.get("id"), 0);
            r.type = U.s(m.get("type"), "");
            r.target = U.s(m.get("target"), "");
            r.by = U.s(m.get("by"), "");
            r.reason = U.s(m.get("reason"), "");
            r.created = m.get("created") instanceof Number ? ((Number) m.get("created")).longValue() : 0;
            r.until = m.get("until") instanceof Number ? ((Number) m.get("until")).longValue() : 0;
            r.active = U.b(m.get("active"), false);
            r.lifted = U.b(m.get("lifted"), false);
            recs.add(r);
            next = Math.max(next, r.id + 1);
        }
    }

    public synchronized void save() {
        List<Object> out = new ArrayList<>();
        for (Rec r : recs) {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("id", r.id); m.put("type", r.type); m.put("target", r.target); m.put("by", r.by);
            m.put("reason", r.reason); m.put("created", r.created); m.put("until", r.until);
            m.put("active", r.active); m.put("lifted", r.lifted);
            out.add(m);
        }
        cfg.set("records", out);
        cfg.save();
    }

    public Rec add(String type, String target, String by, String reason, long until) {
        Rec r = new Rec();
        r.id = next++;
        r.type = type;
        r.target = target;
        r.by = by;
        r.reason = reason;
        r.created = System.currentTimeMillis();
        r.until = until;
        r.active = !type.equals("kick");
        recs.add(r);
        save();
        return r;
    }

    private boolean live(Rec r) {
        if (!r.active) return false;
        if (r.until != 0 && r.until <= System.currentTimeMillis()) { r.active = false; return false; }
        return true;
    }

    /** Действующий бан/мут игрока или null. */
    public Rec active(String type, String target) {
        for (Rec r : recs)
            if (r.type.equals(type) && r.target.equalsIgnoreCase(target) && live(r)) return r;
        return null;
    }

    /** Снять бан/мут. true, если было что снимать. */
    public boolean lift(String type, String target) {
        Rec r = active(type, target);
        if (r == null) return false;
        r.active = false;
        r.lifted = true;
        save();
        return true;
    }

    public List<Rec> activeList(String type) {
        List<Rec> out = new ArrayList<>();
        for (Rec r : recs) if (r.type.equals(type) && live(r)) out.add(r);
        return out;
    }

    public List<Rec> liftedList(String type) {
        List<Rec> out = new ArrayList<>();
        for (Rec r : recs) if (r.type.equals(type) && r.lifted) out.add(r);
        return out;
    }

    public List<Rec> byTarget(String type, String target) {
        List<Rec> out = new ArrayList<>();
        for (Rec r : recs) if (r.type.equals(type) && r.target.equalsIgnoreCase(target)) out.add(r);
        return out;
    }

    public List<Rec> all(String type) {
        List<Rec> out = new ArrayList<>();
        for (Rec r : recs) if (r.type.equals(type)) out.add(r);
        return out;
    }
}
