package me.donate;

import cn.nukkit.Player;
import cn.nukkit.command.CommandSender;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.entity.EntityDamageByEntityEvent;
import cn.nukkit.utils.Config;
import cn.nukkit.utils.TextFormat;

import java.io.File;
import java.util.*;

/** Кланы: создание, приглашения, чат клана, передача лидерства, защита от урона по своим. Данные - clans.yml. */
public class Clans implements Listener {

    private static class Clan {
        String key, name, leader;
        long created;
        List<String> members = new ArrayList<>();
    }

    private final DonatePlugin pl;
    private final Config data;
    private final Map<String, Clan> clans = new LinkedHashMap<>();   // ключ = имя в нижнем регистре
    private final Map<String, String> byPlayer = new HashMap<>();    // ник (нижний регистр) -> ключ клана
    private final Map<UUID, String> invites = new HashMap<>();       // приглашённый -> ключ клана
    private final Map<UUID, Long> inviteTime = new HashMap<>();
    private final Set<UUID> chatOn = new HashSet<>();

    private final int maxMembers, nameMin, nameMax;
    private final long price;
    private final boolean friendlyFire;

    public Clans(DonatePlugin pl, Config cfg) {
        this.pl = pl;
        Map<String, Object> c = U.m(cfg.get("clans"));
        maxMembers = Math.max(2, U.i(c.get("max_members"), 10));
        nameMin = Math.max(2, U.i(c.get("name_min"), 3));
        nameMax = Math.max(nameMin, U.i(c.get("name_max"), 12));
        price = U.i(c.get("create_price_money"), 0);
        friendlyFire = U.b(c.get("friendly_fire"), false);
        data = new Config(new File(pl.getDataFolder(), "clans.yml"), Config.YAML);
        for (Map.Entry<String, Object> e : data.getAll().entrySet()) {
            Map<String, Object> m = U.m(e.getValue());
            Clan cl = new Clan();
            cl.key = e.getKey();
            cl.name = U.s(m.get("name"), cl.key);
            cl.leader = U.s(m.get("leader"), "");
            cl.created = m.get("created") instanceof Number ? ((Number) m.get("created")).longValue() : 0;
            for (Object o : U.l(m.get("members"))) cl.members.add(String.valueOf(o));
            clans.put(cl.key, cl);
            for (String mem : cl.members) byPlayer.put(mem.toLowerCase(Locale.ROOT), cl.key);
        }
    }

    private void save() {
        LinkedHashMap<String, Object> out = new LinkedHashMap<>();
        for (Clan c : clans.values()) {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("name", c.name); m.put("leader", c.leader); m.put("created", c.created);
            m.put("members", new ArrayList<>(c.members));
            out.put(c.key, m);
        }
        data.setAll(out);
        data.save();
    }

    // ------------------------------------------------------------ для других частей плагина

    private Clan of(Player p) {
        String k = byPlayer.get(p.getName().toLowerCase(Locale.ROOT));
        return k == null ? null : clans.get(k);
    }

    /** Для табло: название клана или "нет". */
    public String clanLabel(Player p) {
        Clan c = of(p);
        return c == null ? "§7нет" : "§e" + c.name;
    }

    /** Для чата: тег клана перед ником. */
    public String tag(Player p) {
        Clan c = of(p);
        return c == null ? "" : "§7[§e" + c.name + "§7] ";
    }

    /** Если у игрока включён чат клана - отправляет сообщение клану. true = сообщение обработано. */
    public boolean chatHook(Player p, String msg) {
        if (!chatOn.contains(p.getUniqueId())) return false;
        Clan c = of(p);
        if (c == null) { chatOn.remove(p.getUniqueId()); return false; }
        send(c, p, msg);
        return true;
    }

    public void forget(Player p) {
        invites.remove(p.getUniqueId());
        inviteTime.remove(p.getUniqueId());
        chatOn.remove(p.getUniqueId());
    }

    private void send(Clan c, Player from, String msg) {
        String line = "§6[Клан] §f" + from.getName() + "§7: §e" + msg;
        for (String m : c.members) {
            Player o = pl.getServer().getPlayerExact(m);
            if (o != null) o.sendMessage(line);
        }
        pl.getLogger().info(TextFormat.clean(line + " (" + c.name + ")"));
    }

    private void broadcast(Clan c, String text) {
        for (String m : c.members) {
            Player o = pl.getServer().getPlayerExact(m);
            if (o != null) o.sendMessage(text);
        }
    }

    // ------------------------------------------------------------ команды

    public boolean handle(CommandSender s, String c, String[] a) {
        if (!(s instanceof Player)) { s.sendMessage("Эту команду можно выполнить только в игре."); return true; }
        Player p = (Player) s;
        if (!pl.isAuthed(p)) return true;
        if (c.equals("cc")) {
            Clan cl = of(p);
            if (cl == null) { p.sendMessage("§cВы не состоите в клане."); return true; }
            if (a.length < 1) { p.sendMessage("§c/cc <сообщение>"); return true; }
            if (pl.cmds.punish.active("mute", p.getName()) != null) { p.sendMessage("§cВы замучены."); return true; }
            send(cl, p, String.join(" ", a).replace("§", ""));
            return true;
        }
        String sub = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "help";
        switch (sub) {
            case "create": return create(p, a);
            case "invite": return invite(p, a);
            case "accept": return accept(p);
            case "deny": return deny(p);
            case "leave": return leave(p);
            case "kick": return kick(p, a);
            case "disband": return disband(p, a);
            case "transfer": return transfer(p, a);
            case "info": return info(p, a);
            case "list": case "top": return top(p);
            case "chat": return chat(p);
            default:
                p.sendMessage("§e/clan create <имя> §7- создать клан" + (price > 0 ? " (" + price + " монет)" : "")
                        + "\n§e/clan invite <ник>, accept, deny §7- приглашения"
                        + "\n§e/clan leave, kick <ник>, transfer <ник>, disband"
                        + "\n§e/clan info [имя], /clan top"
                        + "\n§e/clan chat §7- чат клана вкл/выкл, или §e/cc <сообщение>");
                return true;
        }
    }

    private boolean create(Player p, String[] a) {
        if (a.length < 2) { p.sendMessage("§c/clan create <имя>"); return true; }
        if (of(p) != null) { p.sendMessage("§cВы уже состоите в клане."); return true; }
        String name = a[1];
        if (!name.matches("[\\p{L}0-9_]{" + nameMin + "," + nameMax + "}")) {
            p.sendMessage("§cИмя клана: " + nameMin + "-" + nameMax + " символов, буквы, цифры и _.");
            return true;
        }
        String key = name.toLowerCase(Locale.ROOT);
        if (clans.containsKey(key)) { p.sendMessage("§cКлан с таким именем уже есть."); return true; }
        Store.PD d = pl.store.get(p.getName());
        if (price > 0 && !pl.isOwner(p)) {
            if (d.money < price) { p.sendMessage("§cСоздание клана стоит " + price + " монет, у вас " + d.money + "."); return true; }
            d.money -= price;
            pl.store.save();
        }
        Clan cl = new Clan();
        cl.key = key; cl.name = name; cl.leader = p.getName(); cl.created = System.currentTimeMillis();
        cl.members.add(p.getName());
        clans.put(key, cl);
        byPlayer.put(p.getName().toLowerCase(Locale.ROOT), key);
        save();
        p.sendMessage("§aКлан " + name + " создан! Пригласить игрока: /clan invite <ник>");
        pl.getLogger().info(p.getName() + " создал клан " + name);
        return true;
    }

    private boolean invite(Player p, String[] a) {
        Clan cl = of(p);
        if (cl == null) { p.sendMessage("§cВы не состоите в клане."); return true; }
        if (!cl.leader.equalsIgnoreCase(p.getName())) { p.sendMessage("§cПриглашать может только лидер клана."); return true; }
        if (a.length < 2) { p.sendMessage("§c/clan invite <ник>"); return true; }
        if (cl.members.size() >= maxMembers) { p.sendMessage("§cВ клане максимум " + maxMembers + " игроков."); return true; }
        Player t = pl.getServer().getPlayer(a[1]);
        if (t == null || t == p) { p.sendMessage("§cИгрок не найден (должен быть онлайн)."); return true; }
        if (of(t) != null) { p.sendMessage("§cИгрок уже состоит в клане."); return true; }
        invites.put(t.getUniqueId(), cl.key);
        inviteTime.put(t.getUniqueId(), System.currentTimeMillis());
        p.sendMessage("§aПриглашение отправлено игроку " + t.getName() + ".");
        t.sendMessage("§eВас приглашают в клан §6" + cl.name + "§e. Принять: §a/clan accept§e, отклонить: §c/clan deny §7(60 сек)");
        return true;
    }

    private Clan pendingInvite(Player p) {
        String key = invites.get(p.getUniqueId());
        Long t = inviteTime.get(p.getUniqueId());
        if (key == null || t == null || System.currentTimeMillis() - t > 60_000 || !clans.containsKey(key)) {
            p.sendMessage("§cАктивных приглашений нет.");
            return null;
        }
        invites.remove(p.getUniqueId());
        inviteTime.remove(p.getUniqueId());
        return clans.get(key);
    }

    private boolean accept(Player p) {
        Clan cl = pendingInvite(p);
        if (cl == null) return true;
        if (of(p) != null) { p.sendMessage("§cВы уже состоите в клане."); return true; }
        if (cl.members.size() >= maxMembers) { p.sendMessage("§cКлан уже заполнен."); return true; }
        cl.members.add(p.getName());
        byPlayer.put(p.getName().toLowerCase(Locale.ROOT), cl.key);
        save();
        broadcast(cl, "§a" + p.getName() + " вступил в клан!");
        return true;
    }

    private boolean deny(Player p) {
        Clan cl = pendingInvite(p);
        if (cl == null) return true;
        p.sendMessage("§cПриглашение отклонено.");
        Player leader = pl.getServer().getPlayerExact(cl.leader);
        if (leader != null) leader.sendMessage("§c" + p.getName() + " отклонил приглашение в клан.");
        return true;
    }

    private void removeMember(Clan cl, String name) {
        cl.members.removeIf(m -> m.equalsIgnoreCase(name));
        byPlayer.remove(name.toLowerCase(Locale.ROOT));
        Player on = pl.getServer().getPlayerExact(name);
        if (on != null) chatOn.remove(on.getUniqueId());
    }

    private boolean leave(Player p) {
        Clan cl = of(p);
        if (cl == null) { p.sendMessage("§cВы не состоите в клане."); return true; }
        if (cl.leader.equalsIgnoreCase(p.getName())) {
            p.sendMessage("§cЛидер не может выйти. Передайте клан (/clan transfer <ник>) или распустите (/clan disband).");
            return true;
        }
        removeMember(cl, p.getName());
        save();
        p.sendMessage("§eВы вышли из клана " + cl.name + ".");
        broadcast(cl, "§e" + p.getName() + " покинул клан.");
        return true;
    }

    private boolean kick(Player p, String[] a) {
        Clan cl = of(p);
        if (cl == null || !cl.leader.equalsIgnoreCase(p.getName())) { p.sendMessage("§cКикать может только лидер клана."); return true; }
        if (a.length < 2) { p.sendMessage("§c/clan kick <ник>"); return true; }
        String target = cl.members.stream().filter(m -> m.equalsIgnoreCase(a[1])).findFirst().orElse(null);
        if (target == null) { p.sendMessage("§cТакого игрока нет в вашем клане."); return true; }
        if (target.equalsIgnoreCase(cl.leader)) { p.sendMessage("§cСебя исключить нельзя."); return true; }
        removeMember(cl, target);
        save();
        Player on = pl.getServer().getPlayerExact(target);
        if (on != null) on.sendMessage("§cВас исключили из клана " + cl.name + ".");
        broadcast(cl, "§e" + target + " исключён из клана.");
        return true;
    }

    private boolean transfer(Player p, String[] a) {
        Clan cl = of(p);
        if (cl == null || !cl.leader.equalsIgnoreCase(p.getName())) { p.sendMessage("§cПередать клан может только лидер."); return true; }
        if (a.length < 2) { p.sendMessage("§c/clan transfer <ник>"); return true; }
        String target = cl.members.stream().filter(m -> m.equalsIgnoreCase(a[1])).findFirst().orElse(null);
        if (target == null || target.equalsIgnoreCase(p.getName())) { p.sendMessage("§cУкажите другого игрока из вашего клана."); return true; }
        cl.leader = target;
        save();
        broadcast(cl, "§6" + target + " теперь лидер клана " + cl.name + ".");
        return true;
    }

    /** /clan disband - лидер распускает свой клан; админ может распустить любой: /clan disband <имя>. */
    private boolean disband(Player p, String[] a) {
        Clan cl;
        if (a.length >= 2 && p.hasPermission("donate.admin")) {
            cl = clans.get(a[1].toLowerCase(Locale.ROOT));
            if (cl == null) { p.sendMessage("§cТакого клана нет."); return true; }
        } else {
            cl = of(p);
            if (cl == null || !cl.leader.equalsIgnoreCase(p.getName())) { p.sendMessage("§cРаспустить клан может только лидер."); return true; }
        }
        broadcast(cl, "§cКлан " + cl.name + " распущен.");
        for (String m : new ArrayList<>(cl.members)) removeMember(cl, m);
        clans.remove(cl.key);
        save();
        pl.getLogger().info(p.getName() + " распустил клан " + cl.name);
        return true;
    }

    private boolean info(Player p, String[] a) {
        Clan cl = a.length > 1 ? clans.get(a[1].toLowerCase(Locale.ROOT)) : of(p);
        if (cl == null) { p.sendMessage(a.length > 1 ? "§cТакого клана нет." : "§cВы не состоите в клане. /clan help"); return true; }
        StringBuilder sb = new StringBuilder("§6Клан " + cl.name + " §7(" + cl.members.size() + "/" + maxMembers + ")\n§7Лидер: §f" + cl.leader + "\n§7Игроки: ");
        for (int i = 0; i < cl.members.size(); i++) {
            String m = cl.members.get(i);
            sb.append(pl.getServer().getPlayerExact(m) != null ? "§a" : "§8").append(m);
            if (i < cl.members.size() - 1) sb.append("§7, ");
        }
        p.sendMessage(sb.toString());
        return true;
    }

    private boolean top(Player p) {
        if (clans.isEmpty()) { p.sendMessage("§7Кланов пока нет. Создать: /clan create <имя>"); return true; }
        List<Clan> l = new ArrayList<>(clans.values());
        l.sort((x, y) -> y.members.size() - x.members.size());
        StringBuilder sb = new StringBuilder("§6Топ кланов:");
        for (int i = 0; i < Math.min(10, l.size()); i++)
            sb.append("\n§e").append(i + 1).append(". §f").append(l.get(i).name).append(" §7- ").append(l.get(i).members.size()).append(" игроков");
        p.sendMessage(sb.toString());
        return true;
    }

    private boolean chat(Player p) {
        if (of(p) == null) { p.sendMessage("§cВы не состоите в клане."); return true; }
        boolean on = chatOn.add(p.getUniqueId());
        if (!on) chatOn.remove(p.getUniqueId());
        p.sendMessage(on ? "§aЧат клана включён: все сообщения видит только клан." : "§cЧат клана выключен: пишете в общий чат.");
        return true;
    }

    // ------------------------------------------------------------ события

    /** Соклановцы не бьют друг друга (config.yml -> clans.friendly_fire). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (friendlyFire) return;
        if (!(e.getEntity() instanceof Player) || !(e.getDamager() instanceof Player)) return;
        Player v = (Player) e.getEntity(), d = (Player) e.getDamager();
        Clan a = of(d), b = of(v);
        if (a != null && a == b) {
            e.setCancelled(true);
            d.sendTip("§cЭто ваш соклановец");
        }
    }
}
